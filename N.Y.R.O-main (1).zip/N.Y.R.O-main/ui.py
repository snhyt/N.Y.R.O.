from __future__ import annotations
import sys
import json
import math
import os
import platform
import random
import threading
import time
from pathlib import Path
import psutil
import keyboard

from PyQt6.QtCore import Qt, QTimer, pyqtSignal, QRectF, QPointF, QSize, QUrl, pyqtSignal, QObject
from PyQt6.QtGui import (
    QColor, QFont, QPainter, QPen, QPixmap, QBrush, QPainterPath, 
    QDragEnterEvent, QDropEvent
)
from PyQt6.QtWidgets import (
    QApplication, QHBoxLayout, QLabel, QLineEdit, QMainWindow, QPushButton, 
    QVBoxLayout, QWidget, QGridLayout, QSizePolicy, QTextEdit, QFrame, 
    QFileDialog, QScrollArea
)

def _base_dir() -> Path:
    if getattr(sys, "frozen", False):
        return Path(sys.executable).parent
    return Path(__file__).resolve().parent

BASE_DIR   = _base_dir()
CONFIG_DIR = BASE_DIR / "config"
API_FILE   = CONFIG_DIR / "api_keys.json"
_OS = platform.system()

class FloatingControlBox(QWidget):
    toggle_main_signal = pyqtSignal()

    def __init__(self, main_ui_reference):
        super().__init__()
        self.main_ui = main_ui_reference
        
        self.setWindowFlags(
            Qt.WindowType.WindowStaysOnTopHint | 
            Qt.WindowType.FramelessWindowHint | 
            Qt.WindowType.Tool
        )
        self.setGeometry(100, 100, 320, 90) 
        self.setStyleSheet("background-color: #0a0a0a; border: 2px solid #ff0000; border-radius: 15px;")
        
        layout = QHBoxLayout()
        self.call_btn = QPushButton("📞")
        self.call_btn.setStyleSheet("background-color: #333; color: white; font-size: 26px; border-radius: 25px; min-width: 50px; min-height: 50px;")
        
        self.mute_btn = QPushButton("🔇")
        self.mute_btn.setStyleSheet("background-color: #333; color: white; font-size: 26px; border-radius: 25px; min-width: 50px; min-height: 50px;")
        
        self.status_light = QLabel()
        self.status_light.setFixedSize(30, 30)
        self.set_light("red")
        
        layout.addWidget(self.call_btn)
        layout.addWidget(self.mute_btn)
        layout.addWidget(self.status_light)
        self.setLayout(layout)

        self.toggle_main_signal.connect(self.toggle_ui_state)
        threading.Thread(target=self.listen_for_shortcut, daemon=True).start()

    def set_light(self, color):
        if color == "green":
            self.status_light.setStyleSheet("background-color: #00ff00; border-radius: 15px; border: none;")
        else:
            self.status_light.setStyleSheet("background-color: #ff0000; border-radius: 15px; border: none;")

    def listen_for_shortcut(self):
        try:
            keyboard.add_hotkey('ctrl+shift+q', lambda: self.toggle_main_signal.emit())
            keyboard.wait()
        except Exception:
            pass

    def toggle_ui_state(self):
        if self.isVisible():
            self.hide()
            self.main_ui.show()
            self.main_ui.raise_()
            self.main_ui.activateWindow()
        else:
            self.main_ui.hide()
            self.show()

class C:
    BG        = "#020000"
    PANEL     = "#050000"
    PANEL2    = "#0a0000"
    BORDER    = "#aa0000"
    BORDER_A  = "#ff3333"
    BORDER_B  = "#cc0000"
    BORDER_DIM= "#550000"
    PRI       = "#ff0000"
    PRI_DIM   = "#cc0000"
    PRI_GHO   = "#220000"
    ACC       = "#ff0000"
    TEXT      = "#ffcccc"
    TEXT_DIM  = "#a35555"
    TEXT_MED  = "#cc7777"
    WHITE     = "#ffffff"
    GREEN     = "#00ff33" 

def qcol(h: str, a: int = 255) -> QColor:
    c = QColor(h)
    c.setAlpha(a)
    return c

def _resolve_asset_path(filename: str) -> str:
    paths_to_check = [
        Path(filename).resolve(),
        (BASE_DIR / filename).resolve(),
        (Path(sys.argv[0]).parent / filename).resolve(),
        (Path.cwd() / filename).resolve()
    ]
    for p in paths_to_check:
        if p.exists():
            return str(p)
    return filename

_FILE_ICONS = {
    "image":   ("🖼", C.PRI), "video":   ("🎬", C.PRI),
    "audio":   ("🎵", C.PRI), "pdf":     ("📄", C.PRI),
    "word":    ("📝", C.PRI), "excel":   ("📊", C.PRI),
    "code":    ("💻", C.PRI), "archive": ("📦", C.PRI),
    "pptx":    ("📊", C.PRI), "text":    ("📃", C.PRI),
    "data":    ("🔧", C.PRI), "unknown": ("📎", C.PRI),
}
_EXT_TO_CAT = {
    **dict.fromkeys(["jpg","jpeg","png","gif","webp","bmp","tiff","svg","ico"], "image"),
    **dict.fromkeys(["mp4","avi","mov","mkv","wmv","flv","webm","m4v"],         "video"),
    **dict.fromkeys(["mp3","wav","ogg","m4a","aac","flac","wma","opus"],        "audio"),
    **dict.fromkeys(["pdf"],                                                     "pdf"),
    **dict.fromkeys(["doc","docx"],                                              "word"),
    **dict.fromkeys(["xls","xlsx","ods"],                                        "excel"),
    **dict.fromkeys(["ppt","pptx"],                                              "pptx"),
    **dict.fromkeys(["py","js","ts","jsx","tsx","html","css","java","c","cpp",
                     "cs","go","rs","rb","php","swift","kt","sh","sql","lua"],   "code"),
    **dict.fromkeys(["zip","rar","tar","gz","7z","bz2","xz"],                   "archive"),
    **dict.fromkeys(["txt","md","rst","log"],                                    "text"),
    **dict.fromkeys(["csv","tsv","json","xml"],                                  "data"),
}

def _file_category(path: Path) -> str:
    return _EXT_TO_CAT.get(path.suffix.lower().lstrip("."), "unknown")

def _fmt_size(size: int) -> str:
    if   size < 1024:    return f"{size} B"
    elif size < 1024**2: return f"{size/1024:.1f} KB"
    elif size < 1024**3: return f"{size/1024**2:.1f} MB"
    else:                return f"{size/1024**3:.1f} GB"

class _SysMetrics:
    def __init__(self):
        self.cpu = 0.0
        self.mem = 0.0
        self.disk = 0.0
        self.net = 0.0   
        self.tmp = 0.0
        self._lock = threading.Lock()
        self._last_net = psutil.net_io_counters()
        self._last_net_t = time.time()
        self._running = True
        threading.Thread(target=self._loop, daemon=True).start()

    def _loop(self):
        while self._running:
            try:
                self._update()
            except Exception:
                pass
            time.sleep(3.0)

    def _update(self):
        cpu = psutil.cpu_percent(interval=None)
        mem = psutil.virtual_memory().percent
        disk = psutil.disk_usage('/').percent
        
        nc  = psutil.net_io_counters()
        now = time.time()
        dt  = now - self._last_net_t
        if dt > 0:
            sent = (nc.bytes_sent - self._last_net.bytes_sent) / dt
            recv = (nc.bytes_recv - self._last_net.bytes_recv) / dt
            net  = (sent + recv) / 1024
        else:
            net = 0.0
            
        self._last_net   = nc
        self._last_net_t = now

        tmp = -1.0
        try:
            temps = psutil.sensors_temperatures()
            for name, entries in temps.items():
                if entries:
                    tmp = entries[0].current
                    break
        except:
            pass

        with self._lock:
            self.cpu = cpu
            self.mem = mem
            self.disk = disk
            self.net = net
            self.tmp = tmp

    def snapshot(self) -> dict:
        with self._lock:
            return {"cpu": self.cpu, "mem": self.mem, "disk": self.disk, "net": self.net, "tmp": self.tmp}

_metrics = _SysMetrics()

class StyledPanel(QFrame):
    def __init__(self, title: str = "", parent=None):
        super().__init__(parent)
        self.setStyleSheet(f"""
            StyledPanel {{
                background-color: {C.PANEL};
                border: 1px solid {C.BORDER};
                border-radius: 8px;
            }}
        """)
        self.layout = QVBoxLayout(self)
        self.layout.setContentsMargins(15, 15, 15, 15)
        self.layout.setSpacing(10)
        
        if title:
            header_layout = QHBoxLayout()
            lbl = QLabel(title)
            lbl.setFont(QFont("Courier New", 10, QFont.Weight.Bold))
            lbl.setStyleSheet(f"color: {C.PRI}; border: none; background: transparent;")
            header_layout.addWidget(lbl)
            
            icon = QLabel("...")
            icon.setFont(QFont("Courier New", 10, QFont.Weight.Bold))
            icon.setStyleSheet(f"color: {C.PRI_DIM}; border: none; background: transparent;")
            header_layout.addWidget(icon, alignment=Qt.AlignmentFlag.AlignRight)
            
            self.layout.addLayout(header_layout)

class MetricBar(QWidget):
    def __init__(self, icon: str, label: str, parent=None):
        super().__init__(parent)
        self.setFixedHeight(40)
        self.label = label
        self.icon = icon
        self.value = 0.0

    def set_value(self, val: float):
        self.value = max(0.0, min(100.0, val))
        self.update()

    def paintEvent(self, _):
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        W, H = self.width(), self.height()

        p.setPen(QPen(qcol(C.BORDER), 1.5))
        p.drawEllipse(0, 5, 30, 30)
        p.setFont(QFont("Courier New", 12))
        p.setPen(QPen(qcol(C.PRI), 1))
        p.drawText(QRectF(0, 5, 30, 30), Qt.AlignmentFlag.AlignCenter, self.icon)

        p.setFont(QFont("Courier New", 9))
        p.setPen(QPen(qcol(C.TEXT), 1))
        p.drawText(QRectF(45, 5, 100, 15), Qt.AlignmentFlag.AlignLeft, self.label)
        p.drawText(QRectF(W - 50, 5, 50, 15), Qt.AlignmentFlag.AlignRight, f"{int(self.value)}%")

        bar_y = 25
        bar_w = W - 45
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(QBrush(qcol(C.PRI_GHO)))
        p.drawRoundedRect(QRectF(45, bar_y, bar_w, 4), 2, 2)

        fill_w = bar_w * (self.value / 100.0)
        if fill_w > 0:
            p.setBrush(QBrush(qcol(C.PRI)))
            p.drawRoundedRect(QRectF(45, bar_y, fill_w, 4), 2, 2)

class PhoneBoothWidget(QFrame):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setStyleSheet(f"background-color: {C.PANEL}; border: 1px solid {C.BORDER}; border-radius: 8px;")
        self.setFixedHeight(100)
        
        lay = QHBoxLayout(self)
        lay.setAlignment(Qt.AlignmentFlag.AlignCenter)
        lay.setSpacing(40)
        
        self.phone_btn = QPushButton("📞")
        self.phone_btn.setFixedSize(60, 60)
        self.phone_btn.setFont(QFont("Segoe UI Emoji" if _OS == "Windows" else "Arial", 22))
        
        self.mute_btn = QPushButton("🎙")
        self.mute_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.mute_btn.setFixedSize(60, 60)
        self.mute_btn.setFont(QFont("Segoe UI Emoji" if _OS == "Windows" else "Arial", 22))
        
        lay.addWidget(self.phone_btn)
        lay.addWidget(self.mute_btn)
        self.set_state("LISTENING", False)
        
    def set_state(self, state: str, is_muted: bool):
        btn_base = "border-radius: 30px; font-weight: bold;"
        
        if is_muted:
            self.mute_btn.setText("🔇")
            self.mute_btn.setStyleSheet(f"background: {C.PRI_GHO}; color: {C.BORDER_DIM}; border: 2px solid {C.BORDER_DIM}; {btn_base}")
        else:
            self.mute_btn.setText("🎙")
            self.mute_btn.setStyleSheet(f"background: {C.PANEL2}; color: {C.WHITE}; border: 2px solid {C.BORDER}; {btn_base}")
            
        if state == "LISTENING":
            self.phone_btn.setStyleSheet(f"background: #330000; color: #ff0000; border: 2px solid #ff0000; {btn_base}")
        elif state in ["PROCESSING", "THINKING", "SPEAKING"]:
            self.phone_btn.setStyleSheet(f"background: #003300; color: #00ff33; border: 2px solid #00ff33; {btn_base}")
        elif state == "MUTED":
            self.phone_btn.setStyleSheet(f"background: #111111; color: #555555; border: 2px solid #555555; {btn_base}")
        else:
            self.phone_btn.setStyleSheet(f"background: #330000; color: #ff0000; border: 2px solid #ff0000; {btn_base}")

class HudCanvas(QWidget):
    def __init__(self, face_path: str, parent=None):
        super().__init__(parent)
        self.setAttribute(Qt.WidgetAttribute.WA_OpaquePaintEvent)
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)

        self.muted    = False
        self.speaking = False
        self.state    = "LISTENING..."

        self._tick = 0
        self._rings = [0.0, 120.0, 240.0]
        self._face_px: QPixmap | None = None
        self._load_face("face1.png")

        self._tmr = QTimer(self)
        self._tmr.timeout.connect(self._step)
        self._tmr.start(16)

    def _load_face(self, path: str):
        try:
            from PIL import Image
            import io
            resolved_path = _resolve_asset_path(path)
            if os.path.exists(resolved_path):
                img = Image.open(resolved_path).convert("RGBA")
                pixels = img.getdata()
                new_pixels = []
                for r, g, b, a in pixels:
                    if r < 10 and g < 10 and b < 10:
                        new_pixels.append((0, 0, 0, 0))
                    else:
                        new_pixels.append((r, g, b, r))
                img.putdata(new_pixels)

                buf = io.BytesIO()
                img.save(buf, format="PNG")
                px = QPixmap()
                px.loadFromData(buf.getvalue())
                self._face_px = px
            else:
                self._face_px = None
        except Exception:
            self._face_px = None

    def _step(self):
        self._tick += 1
        speeds = [1.5, -1.0, 0.8] if self.speaking else [0.5, -0.3, 0.2]
        for i, spd in enumerate(speeds):
            self._rings[i] = (self._rings[i] + spd) % 360
        self.update()

    def paintEvent(self, _):
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        p.fillRect(self.rect(), qcol(C.BG))

        W, H = self.width(), self.height()
        cx, cy = W / 2, H / 2
        fw = min(W, H)

        for idx, (r_frac, w_r, arc_l, gap) in enumerate(
            [(0.48, 2, 115, 78), (0.43, 1, 60, 40), (0.38, 1, 90, 60)]
        ):
            ring_r = fw * r_frac
            base   = self._rings[idx]
            col    = qcol(C.PRI, 200 - (idx * 40))
            
            p.setPen(QPen(col, w_r))
            p.setBrush(Qt.BrushStyle.NoBrush)
            
            angle = base
            rect  = QRectF(cx - ring_r, cy - ring_r, ring_r * 2, ring_r * 2)
            while angle < base + 360:
                p.drawArc(rect, int(angle * 16), int(arc_l * 16))
                angle += arc_l + gap

        if self._face_px:
            fsz = int(fw * 1.15) 
            scaled = self._face_px.scaled(
                fsz, fsz,
                Qt.AspectRatioMode.KeepAspectRatio,
                Qt.TransformationMode.SmoothTransformation,
            )
            y_offset = int(fsz * 0.15) 
            p.drawPixmap(int(cx - fsz / 2), int(cy - fsz / 2) + y_offset, scaled)
        else:
            p.setPen(QPen(qcol(C.PRI, 255), 2))
            p.setFont(QFont("Courier New", 18, QFont.Weight.Bold))
            p.drawText(QRectF(cx - 100, cy - 20, 200, 40), Qt.AlignmentFlag.AlignCenter, "NO FACE DATA")

class ClickableMapWidget(QLabel):
    clicked = pyqtSignal()
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.setScaledContents(True)

    def mousePressEvent(self, event):
        self.clicked.emit()

class ChatBubble(QFrame):
    def __init__(self, text: str, sender: str = "sys", timestamp: str = ""):
        super().__init__()
        self.setSizePolicy(QSizePolicy.Policy.Maximum, QSizePolicy.Policy.Preferred)
        
        lay = QVBoxLayout(self)
        lay.setContentsMargins(12, 8, 12, 8)
        lay.setSpacing(2)

        msg_lbl = QLabel(text)
        msg_lbl.setFont(QFont("Courier New", 9))
        msg_lbl.setWordWrap(True)
        msg_lbl.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        lay.addWidget(msg_lbl)

        if timestamp:
            time_lbl = QLabel(timestamp)
            time_lbl.setFont(QFont("Courier New", 7))
            time_lbl.setAlignment(Qt.AlignmentFlag.AlignRight)
            lay.addWidget(time_lbl)
        
        if sender == "you":
            self.setStyleSheet(f"""
                ChatBubble {{
                    background-color: {C.PRI_GHO}; 
                    border: 1px solid {C.BORDER_DIM}; 
                    border-radius: 12px;
                    border-top-right-radius: 0px;
                }}
            """)
            msg_lbl.setStyleSheet(f"color: {C.WHITE}; background: transparent; border: none;")
            if timestamp: time_lbl.setStyleSheet(f"color: {C.TEXT_DIM}; background: transparent; border: none;")
            
        elif sender == "nyro":
            self.setStyleSheet(f"""
                ChatBubble {{
                    background-color: {C.PANEL2}; 
                    border: 1px solid {C.BORDER_A}; 
                    border-radius: 12px;
                    border-top-left-radius: 0px;
                }}
            """)
            msg_lbl.setStyleSheet(f"color: {C.PRI}; background: transparent; border: none;")
            if timestamp: time_lbl.setStyleSheet(f"color: {C.PRI_DIM}; background: transparent; border: none;")
            
        else:
            self.setStyleSheet("background: transparent; border: none;")
            msg_lbl.setStyleSheet(f"color: {C.TEXT_DIM}; font-style: italic;")
            msg_lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)

class ChatLogWidget(QScrollArea):
    _sig = pyqtSignal(str)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWidgetResizable(True)
        self.setStyleSheet(f"""
            QScrollArea {{ background: transparent; border: none; }}
            QScrollBar:vertical {{ background: {C.BG}; width: 6px; }}
            QScrollBar::handle:vertical {{ background: {C.BORDER}; border-radius: 3px; }}
        """)
        
        self.container = QWidget()
        self.container.setStyleSheet("background: transparent;")
        
        self.vbox = QVBoxLayout(self.container)
        self.vbox.setAlignment(Qt.AlignmentFlag.AlignTop)
        self.vbox.setSpacing(10)
        self.vbox.setContentsMargins(5, 5, 15, 5)
        
        self.setWidget(self.container)
        self._sig.connect(self._add_bubble)
        
    def append_log(self, text: str):
        self._sig.emit(text)
        
    def _add_bubble(self, text: str):
        ts = time.strftime("%H:%M")
        display_text = text
        sender = "sys"
        
        if text.startswith("You: "):
            sender = "you"
            display_text = text[5:]
        elif text.startswith("NYRO: "):
            sender = "nyro"
            display_text = text[7:]
        elif text.startswith("SYS: "):
            sender = "sys"
            display_text = text[5:]
            
        bubble = ChatBubble(display_text, sender, ts if sender != "sys" else "")
        bubble.setMaximumWidth(int(self.width() * 0.85)) 
        
        row = QHBoxLayout()
        row.setContentsMargins(0, 0, 0, 0)
        
        if sender == "you":
            row.addStretch()
            row.addWidget(bubble)
        elif sender == "nyro":
            row.addWidget(bubble)
            row.addStretch()
        else:
            row.addWidget(bubble)
            
        self.vbox.addLayout(row)
        QTimer.singleShot(50, self._scroll_to_bottom)
        
    def _scroll_to_bottom(self):
        sb = self.verticalScrollBar()
        sb.setValue(sb.maximum())

class FileDropZone(QWidget):
    file_selected = pyqtSignal(str)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setAcceptDrops(True)
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        self._current_file: str | None = None
        self._hovering  = False
        self._drag_over = False
        self._dash_offset = 0.0
        self._anim_tmr = QTimer(self)
        self._anim_tmr.timeout.connect(self._animate)
        self._anim_tmr.start(40)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)
        self._canvas = _DropCanvas(self)
        layout.addWidget(self._canvas)

    def _animate(self):
        self._dash_offset = (self._dash_offset + 0.8) % 20
        self._canvas.update()

    def dragEnterEvent(self, e: QDragEnterEvent):
        if e.mimeData().hasUrls():
            e.acceptProposedAction()
            self._drag_over = True; self._canvas.update()

    def dragLeaveEvent(self, e):
        self._drag_over = False; self._canvas.update()

    def dropEvent(self, e: QDropEvent):
        self._drag_over = False
        urls = e.mimeData().urls()
        if urls:
            path = urls[0].toLocalFile()
            if Path(path).is_file():
                self._set_file(path)
        self._canvas.update()

    def mousePressEvent(self, e):
        if e.button() == Qt.MouseButton.LeftButton:
            self._browse()

    def enterEvent(self, e):
        self._hovering = True; self._canvas.update()

    def leaveEvent(self, e):
        self._hovering = False; self._canvas.update()

    def current_file(self) -> str | None:
        return self._current_file

    def clear_file(self):
        self._current_file = None; self._canvas.update()

    def _browse(self):
        path, _ = QFileDialog.getOpenFileName(
            self, "Select a file to Upload", str(Path.home()),
            "All Files (*.*);;"
            "Images (*.jpg *.jpeg *.png *.gif);;"
            "Documents (*.pdf *.docx *.txt *.md *.csv *.xlsx);;"
            "Code (*.py *.js *.html *.css);;"
        )
        if path:
            self._set_file(path)

    def _set_file(self, path: str):
        self._current_file = path
        self._canvas.update()
        self.file_selected.emit(path)

class _DropCanvas(QWidget):
    def __init__(self, zone: FileDropZone):
        super().__init__(zone)
        self._z = zone

    def paintEvent(self, _):
        p = QPainter(self)
        p.setRenderHint(QPainter.RenderHint.Antialiasing)
        z    = self._z
        W, H = self.width(), self.height()
        pad  = 4
        rect = QRectF(pad, pad, W - pad * 2, H - pad * 2)

        bg_col = qcol(C.PANEL2 if z._hovering else C.PANEL)
        p.setBrush(QBrush(bg_col)); p.setPen(Qt.PenStyle.NoPen)
        p.drawRoundedRect(rect, 6, 6)

        if z._current_file:   border_col = qcol(C.PRI, 200)
        elif z._drag_over:    border_col = qcol(C.PRI, 230)
        elif z._hovering:     border_col = qcol(C.BORDER_A, 200)
        else:                 border_col = qcol(C.BORDER, 160)

        pen = QPen(border_col, 1.5, Qt.PenStyle.DashLine)
        pen.setDashOffset(z._dash_offset)
        p.setPen(pen); p.setBrush(Qt.BrushStyle.NoBrush)
        p.drawRoundedRect(rect, 6, 6)

        if z._current_file:   self._paint_file(p, W, H)
        elif z._drag_over:    self._paint_drag_over(p, W, H)
        else:                 self._paint_idle(p, W, H, z._hovering)

    def _paint_idle(self, p, W, H, hover):
        cx, cy = W / 2, H / 2
        col = qcol(C.PRI_DIM if not hover else C.PRI)
        p.setPen(QPen(col, 2)); p.setBrush(Qt.BrushStyle.NoBrush)
        p.drawLine(QPointF(cx, cy - 14), QPointF(cx, cy + 4))
        p.drawLine(QPointF(cx - 8, cy - 6), QPointF(cx, cy - 14))
        p.drawLine(QPointF(cx + 8, cy - 6), QPointF(cx, cy - 14))
        p.drawLine(QPointF(cx - 14, cy + 4), QPointF(cx + 14, cy + 4))
        p.setFont(QFont("Courier New", 8))
        p.setPen(QPen(qcol(C.PRI_DIM if not hover else C.TEXT), 1))
        p.drawText(QRectF(0, cy + 10, W, 16), Qt.AlignmentFlag.AlignCenter, "Drop file here or Click")

    def _paint_drag_over(self, p, W, H):
        cx, cy = W / 2, H / 2
        p.setFont(QFont("Courier New", 20))
        p.setPen(QPen(qcol(C.PRI), 1))
        p.drawText(QRectF(0, cy - 20, W, 32), Qt.AlignmentFlag.AlignCenter, "⬇")
        p.setFont(QFont("Courier New", 8, QFont.Weight.Bold))
        p.setPen(QPen(qcol(C.PRI), 1))
        p.drawText(QRectF(0, cy + 10, W, 16), Qt.AlignmentFlag.AlignCenter, "Release to load")

    def _paint_file(self, p, W, H):
        path = Path(self._z._current_file)
        cat  = _file_category(path)
        icon, icon_col = _FILE_ICONS.get(cat, _FILE_ICONS["unknown"])
        size_str = _fmt_size(path.stat().st_size)

        block_x, block_w = 10, 40
        p.setFont(QFont("Segoe UI Emoji", 20) if _OS == "Windows" else QFont("Arial", 20))
        p.setPen(QPen(qcol(icon_col), 1))
        p.drawText(QRectF(block_x, 0, block_w, H), Qt.AlignmentFlag.AlignCenter, icon)

        tx = block_x + block_w + 6
        tw = W - tx - 28

        p.setFont(QFont("Courier New", 8, QFont.Weight.Bold))
        p.setPen(QPen(qcol(C.WHITE), 1))
        name = path.name if len(path.name) <= 22 else path.name[:19] + "..."
        p.drawText(QRectF(tx, H * 0.25, tw, 16), Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter, name)

        p.setFont(QFont("Courier New", 7))
        p.setPen(QPen(qcol(C.TEXT_DIM), 1))
        p.drawText(QRectF(tx, H * 0.25 + 16, tw, 14), Qt.AlignmentFlag.AlignLeft | Qt.AlignmentFlag.AlignVCenter, size_str)

        p.setFont(QFont("Courier New", 9, QFont.Weight.Bold))
        p.setPen(QPen(qcol(C.PRI, 180), 1))
        p.drawText(QRectF(W - 24, 0, 20, H), Qt.AlignmentFlag.AlignCenter, "✕")

    def mousePressEvent(self, e):
        z = self._z
        if z._current_file and e.pos().x() > self.width() - 30:
            z.clear_file()
        else:
            z.mousePressEvent(e)

class RemoteKeyOverlay(QWidget):
    closed = pyqtSignal()

    def __init__(self, url: str, key: str, auto_login_url: str = "", manual_url: str = "", expiry_secs: int = 600, parent=None):
        super().__init__(parent)
        self.setAttribute(Qt.WidgetAttribute.WA_StyledBackground, True)
        self.setStyleSheet(f"""
            RemoteKeyOverlay {{
                background: rgba(5, 0, 0, 0.95);
                border: 1px solid {C.BORDER};
                border-radius: 14px;
            }}
        """)
        self._expiry          = time.time() + expiry_secs
        self._on_new_key      = None
        self._auto_login_url  = auto_login_url
        self._manual_url      = manual_url or url

        lay = QVBoxLayout(self)
        lay.setContentsMargins(24, 16, 24, 16)
        lay.setSpacing(5)

        def _lbl(txt, fs=9, bold=False, color=C.PRI, align=Qt.AlignmentFlag.AlignCenter):
            w = QLabel(txt)
            w.setAlignment(align)
            w.setFont(QFont("Courier New", fs, QFont.Weight.Bold if bold else QFont.Weight.Normal))
            w.setStyleSheet(f"color: {color}; background: transparent;")
            w.setWordWrap(True)
            return w

        lay.addWidget(_lbl("◈  REMOTE ACCESS", 12, True))
        sep = QFrame(); sep.setFrameShape(QFrame.Shape.HLine)
        sep.setStyleSheet(f"color: {C.BORDER}; margin: 1px 0;")
        lay.addWidget(sep)

        self._qr_label = QLabel()
        self._qr_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self._qr_label.setFixedSize(176, 176)
        self._qr_label.setStyleSheet("background: white; border-radius: 10px; padding: 4px;")
        qr_row = QHBoxLayout()
        qr_row.addStretch()
        qr_row.addWidget(self._qr_label)
        qr_row.addStretch()
        lay.addLayout(qr_row)

        self._update_qr(auto_login_url)

        lay.addWidget(_lbl("Scan with phone camera to connect instantly", 8, color=C.TEXT_DIM))

        sep2 = QFrame(); sep2.setFrameShape(QFrame.Shape.HLine)
        sep2.setStyleSheet(f"color: {C.BORDER}; margin: 1px 0;")
        lay.addWidget(sep2)

        lay.addWidget(_lbl("Or enter manually:", 7, color=C.TEXT_DIM, align=Qt.AlignmentFlag.AlignLeft))

        self._url_lbl = QLabel(self._manual_url)
        self._url_lbl.setFont(QFont("Courier New", 8))
        self._url_lbl.setStyleSheet(f"color: {C.PRI_DIM}; background: transparent;")
        self._url_lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self._url_lbl.setTextInteractionFlags(Qt.TextInteractionFlag.TextSelectableByMouse)
        lay.addWidget(self._url_lbl)

        self._key_lbl = QLabel(key)
        self._key_lbl.setFont(QFont("Courier New", 28, QFont.Weight.Bold))
        self._key_lbl.setStyleSheet(f"""
            color: {C.PRI};
            background: {C.PANEL2};
            border: 1px solid {C.BORDER_A};
            border-radius: 8px;
            padding: 6px 4px;
            letter-spacing: 10px;
        """)
        self._key_lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
        lay.addWidget(self._key_lbl)

        self._timer_lbl = QLabel()
        self._timer_lbl.setFont(QFont("Courier New", 8))
        self._timer_lbl.setStyleSheet(f"color: {C.TEXT_MED}; background: transparent;")
        self._timer_lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
        lay.addWidget(self._timer_lbl)

        btn_row = QHBoxLayout(); btn_row.setSpacing(8)
        new_btn = QPushButton("NEW KEY")
        new_btn.setFixedHeight(32)
        new_btn.setFont(QFont("Courier New", 8, QFont.Weight.Bold))
        new_btn.setStyleSheet(f"background: {C.PANEL}; color: {C.PRI}; border: 1px solid {C.PRI_DIM}; border-radius: 5px;")
        new_btn.clicked.connect(self._refresh_key)
        btn_row.addWidget(new_btn)

        close_btn = QPushButton("DISMISS")
        close_btn.setFixedHeight(32)
        close_btn.setFont(QFont("Courier New", 8, QFont.Weight.Bold))
        close_btn.setStyleSheet(f"background: transparent; color: {C.TEXT_MED}; border: 1px solid {C.BORDER}; border-radius: 5px;")
        close_btn.clicked.connect(self._do_close)
        btn_row.addWidget(close_btn)
        lay.addLayout(btn_row)

        self._ctimer = QTimer(self)
        self._ctimer.timeout.connect(self._tick)
        self._ctimer.start(1000)
        self._tick()

    def set_new_key_callback(self, fn) -> None:
        self._on_new_key = fn

    def _update_qr(self, url: str) -> None:
        if not url:
            self._qr_label.setText("—")
            return
        try:
            import qrcode as _qrmod
            from io import BytesIO
            qr = _qrmod.QRCode(box_size=5, border=2, error_correction=_qrmod.constants.ERROR_CORRECT_M)
            qr.add_data(url)
            qr.make(fit=True)
            img = qr.make_image(fill_color="black", back_color="white")
            buf = BytesIO()
            img.save(buf, format="PNG")
            px = QPixmap()
            px.loadFromData(buf.getvalue())
            self._qr_label.setPixmap(px.scaled(170, 170, Qt.AspectRatioMode.KeepAspectRatio, Qt.TransformationMode.SmoothTransformation))
        except ImportError:
            self._qr_label.setText("pip install\nqrcode[pil]")
            self._qr_label.setFont(QFont("Courier New", 8))
            self._qr_label.setStyleSheet("color: #888; background: white; border-radius: 10px; padding: 4px;")
        except Exception:
            self._qr_label.setText(url[:28])

    def _tick(self):
        remaining = max(0, int(self._expiry - time.time()))
        m, s = divmod(remaining, 60)
        self._timer_lbl.setText(f"Key expires in  {m:02d}:{s:02d}")
        if remaining == 0:
            self._do_close()

    def mark_connected(self) -> None:
        self._ctimer.stop()
        self._key_lbl.setText("CONNECTED")
        self._key_lbl.setStyleSheet(f"""
            color: {C.GREEN};
            background: rgba(0,255,51,0.08);
            border: 2px solid rgba(0,255,51,0.4);
            border-radius: 8px;
            padding: 6px 4px;
            letter-spacing: 4px;
        """)
        self._qr_label.setText("✓")
        self._qr_label.setFont(QFont("Courier New", 54, QFont.Weight.Bold))
        self._qr_label.setStyleSheet(f"color: {C.GREEN}; background: #001a0d; border-radius: 10px;")
        self._timer_lbl.setText("Phone connected — NYRO ready")
        self._timer_lbl.setStyleSheet(f"color: {C.GREEN}; background: transparent;")

    def _refresh_key(self):
        if self._on_new_key:
            result = self._on_new_key()
            if result:
                url, key = result[0], result[1]
                auto   = result[2] if len(result) >= 3 else ""
                manual = result[3] if len(result) >= 4 else url
                self._manual_url = manual or url
                self._url_lbl.setText(self._manual_url)
                self._key_lbl.setText(key)
                self._auto_login_url = auto
                self._update_qr(auto or url)
                self._expiry = time.time() + 600
                self._key_lbl.setStyleSheet(f"color: {C.PRI}; background: {C.PANEL2}; border: 1px solid {C.BORDER_A}; border-radius: 8px; padding: 6px 4px; letter-spacing: 10px;")
                self._timer_lbl.setStyleSheet(f"color: {C.TEXT_MED}; background: transparent;")
                self._ctimer.start(1000)
                self._tick()

    def _do_close(self):
        self._ctimer.stop()
        self.hide()
        self.closed.emit()
# 1. ADD THIS ASSISTANT CLASS RIGHT ABOVE YOUR MAIN WINDOW CLASS
class WeatherSignalBridge(QObject):
    weather_ready = pyqtSignal(str, str, str, str, str)

class MainWindow(QMainWindow):
    _log_sig   = pyqtSignal(str)
    _state_sig = pyqtSignal(str)
    global_mute_sig = pyqtSignal()
    wake_signal = pyqtSignal()

    def ask_nyro(self, user_message):
        if not self.ai_client:
            print("❌ Error: AI Brain is not connected to the UI!")
            return
            
        try:
            print(f"Sending to neural net: '{user_message}'...")
            
            # Send the message to Gemini 3.5 Flash
            response = self.ai_client.models.generate_content(
                model='gemini-3.5-flash',
                contents=user_message
            )
            
            # Print the reply in your terminal
            print(f"🤖 N.Y.R.O.: {response.text}")
            
            # OPTIONAL: If you have a specific text box on your dashboard for logs
            # (like a QTextEdit or QLabel), you can append the text to it right here!
            # For example: self.log_box.append(f"R.O.C.K.Y.: {response.text}")
            
        except Exception as e:
            print(f"AI Communication Error: {e}")
            

    def __init__(self, face_path: str, ai_client=None):
        super().__init__()
        self.ai_client = ai_client
        self.setWindowTitle("N.Y.R.O. - CYBER INTERFACE")
        self.resize(1200, 800)
        self.setStyleSheet(f"background-color: {C.BG};")
        self.setup_weather_bridge()
        self._muted = False
        self._ready = True
        self.on_text_command = None
        self.on_remote_clicked = None
        self._remote_overlay = None

        self.global_mute_sig.connect(self._toggle_mute)
        self.wake_signal.connect(self.force_pop_to_front)
        try:
            keyboard.add_hotkey('ctrl+alt+m', lambda: self.global_mute_sig.emit())
        except Exception:
            pass

        central = QWidget()
        main_layout = QVBoxLayout(central)
        main_layout.setContentsMargins(15, 15, 15, 15)
        main_layout.setSpacing(15)
        self.setCentralWidget(central)

        main_layout.addWidget(self._build_top_bar())

        content_layout = QHBoxLayout()
        content_layout.setSpacing(15)

        left_col = QVBoxLayout()
        self.metrics_panel = self._build_metrics_panel()
        self.map_panel = self._build_map_panel()
        left_col.addWidget(self.metrics_panel, 3)
        left_col.addWidget(self.map_panel, 2)
        content_layout.addLayout(left_col, 1)

        center_col = QVBoxLayout()
        self.hud = HudCanvas(face_path)
        center_col.addWidget(self.hud, 1) 
        
        self.phone_booth = PhoneBoothWidget()
        self.phone_booth.mute_btn.clicked.connect(self._toggle_mute)
        center_col.addWidget(self.phone_booth, 0) 
        content_layout.addLayout(center_col, 2)

        right_col = QVBoxLayout()
        self.logs_panel = self._build_logs_panel()
        right_col.addWidget(self.logs_panel, 2)
        
        self.upload_panel = self._build_upload_panel()
        self.upload_panel.setFixedHeight(120) 
        right_col.addWidget(self.upload_panel, 0)
        
        self.controls_panel = self._build_controls_panel()
        right_col.addWidget(self.controls_panel, 0)
        
        content_layout.addLayout(right_col, 1)
        main_layout.addLayout(content_layout, 1)

        self._ui_timer = QTimer(self)
        self._ui_timer.timeout.connect(self._update_metrics)
        self._ui_timer.start(1000)
        self._state_sig.connect(self._on_state_change)

    def force_pop_to_front(self):
        """The ultimate, glitch-free Full Screen override using native Windows API."""
        
        # 1. Restore the window normally if it is minimized on the taskbar
        if self.isMinimized():
            self.showNormal()
            
        # 2. Tell the PyQt UI to expand to Full Screen
        self.showFullScreen()
        
        # 3. Use the raw Windows OS API to force focus (Bypasses the anti-focus block safely)
        try:
            import ctypes
            hwnd = int(self.winId())
            # Force the window to the absolute foreground
            ctypes.windll.user32.SetForegroundWindow(hwnd)
        except Exception:
            pass
            
        # 4. Final internal Qt focus grabs
        self.raise_()
        self.activateWindow()

    def keyPressEvent(self, event):
        """Allows you to press ESC on your keyboard to exit Full Screen mode."""
        if event.key() == Qt.Key.Key_Escape and self.isFullScreen():
            self.showNormal()
        super().keyPressEvent(event)

    def resizeEvent(self, event):
        super().resizeEvent(event)
        if getattr(self, '_remote_overlay', None) and self._remote_overlay.isVisible():
            cw = self.centralWidget()
            ow, oh = 400, 465
            self._remote_overlay.setGeometry((cw.width() - ow) // 2, (cw.height() - oh) // 2, ow, oh)

    def _build_top_bar(self) -> QWidget:
        w = QWidget()
        w.setFixedHeight(60)
        lay = QHBoxLayout(w)
        lay.setContentsMargins(0, 0, 0, 0)
        
        left_box = StyledPanel()
        lbl1 = QLabel("SYSTEM STATUS    <span style='color:#ff0000'>ONLINE</span>")
        lbl1.setFont(QFont("Courier New", 9))
        lbl2 = QLabel("VERSION 3.2.1    UPTIME 02:15:42")
        lbl2.setFont(QFont("Courier New", 8))
        lbl2.setStyleSheet(f"color:{C.TEXT_DIM};")
        left_box.layout.addWidget(lbl1)
        left_box.layout.addWidget(lbl2)
        lay.addWidget(left_box)
        
        center_box = QVBoxLayout()
        title = QLabel("N.Y.R.O")
        title.setFont(QFont("Courier New", 28, QFont.Weight.Bold))
        title.setStyleSheet(f"color: {C.PRI}; letter-spacing: 5px;")
        title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        sub = QLabel("ROBUST • OPERATING• COGNITIVE • KNOWLEDGE • YEILD")
        sub.setFont(QFont("Courier New", 7))
        sub.setStyleSheet(f"color: {C.TEXT_DIM};")
        sub.setAlignment(Qt.AlignmentFlag.AlignCenter)
        center_box.addWidget(title)
        center_box.addWidget(sub)
        lay.addLayout(center_box, 1)
        
        right_box = StyledPanel()
        self.clock_lbl = QLabel("00:00:00")
        self.clock_lbl.setFont(QFont("Courier New", 15, QFont.Weight.Bold))
        self.clock_lbl.setMinimumHeight(30)
        self.clock_lbl.setStyleSheet(f"color: {C.PRI};")
        self.date_lbl = QLabel("TUESDAY, 30 JUN 2026")
        self.date_lbl.setFont(QFont("Courier New", 8))
        self.date_lbl.setStyleSheet(f"color:{C.TEXT_DIM};")
        right_box.layout.addWidget(self.clock_lbl, alignment=Qt.AlignmentFlag.AlignRight)
        right_box.layout.addWidget(self.date_lbl, alignment=Qt.AlignmentFlag.AlignRight)
        lay.addWidget(right_box)
        
        return w

    def _build_metrics_panel(self) -> StyledPanel:
        panel = StyledPanel("SYSTEM METRICS")
        self.bar_cpu = MetricBar("⚙", "CPU USAGE")
        self.bar_ram = MetricBar("▦", "RAM USAGE")
        self.bar_disk = MetricBar("◎", "DISK USAGE")
        self.bar_health = MetricBar("♥", "SYS HEALTH")
        
        panel.layout.addWidget(self.bar_cpu)
        panel.layout.addWidget(self.bar_ram)
        panel.layout.addWidget(self.bar_disk)
        panel.layout.addWidget(self.bar_health)
        panel.layout.addSpacing(15)
        
        self.net_lbl = QLabel("NETWORK             0.0 KB/s")
        self.net_lbl.setFont(QFont("Courier New", 9))
        self.net_lbl.setStyleSheet(f"color:{C.TEXT};")
        panel.layout.addWidget(self.net_lbl)
        panel.layout.addSpacing(5)

        self.temp_lbl = QLabel("CORE TEMP           -- °C")
        self.temp_lbl.setFont(QFont("Courier New", 9))
        self.temp_lbl.setStyleSheet(f"color:{C.TEXT};")
        panel.layout.addWidget(self.temp_lbl)
        panel.layout.addStretch()
        
        self.uptime_lbl = QLabel("⏱ UPTIME            00:00:00")
        self.uptime_lbl.setFont(QFont("Courier New", 9))
        self.uptime_lbl.setStyleSheet(f"color:{C.TEXT_DIM};")
        panel.layout.addWidget(self.uptime_lbl)
        
        return panel

    def _build_map_panel(self) -> StyledPanel:
        panel = StyledPanel("SYSTEM MAP")
        self.map_lbl = ClickableMapWidget()
        resolved_map = _resolve_asset_path("map.png")
        
        try:
            from PIL import Image
            import io
            if os.path.exists(resolved_map):
                img = Image.open(resolved_map).convert("RGBA")
                buf = io.BytesIO()
                img.save(buf, format="PNG")
                px = QPixmap()
                px.loadFromData(buf.getvalue())
                self.map_lbl.setPixmap(px)
                self.map_lbl.setMinimumSize(250, 180) 
            else:
                self.map_lbl.setText(f"[MAP NOT FOUND:\n{resolved_map}]")
                self.map_lbl.setStyleSheet(f"color: {C.PRI}; border: 1px dashed {C.BORDER};")
        except Exception as e:
            self.map_lbl.setText(f"[MAP ERROR: {e}]")
            self.map_lbl.setStyleSheet(f"color: {C.PRI_DIM};")
            
        self.map_lbl.clicked.connect(self._on_map_clicked)
        panel.layout.addWidget(self.map_lbl, 1)
        return panel

    def _on_map_clicked(self):
        self._log.append_log("SYS: Accessing Live Weather HUD...")
        if self.on_text_command:
            cmd = "Show weather map [SYSTEM OVERRIDE: Launch browser_control with action='go_to' and url='https://www.windy.com' immediately.]"
            threading.Thread(target=self.on_text_command, args=(cmd,), daemon=True).start()

    def _build_upload_panel(self) -> StyledPanel:
        panel = StyledPanel("FILE UPLOAD")
        self._drop_zone = FileDropZone()
        self._drop_zone.file_selected.connect(self._on_file_selected)
        panel.layout.addWidget(self._drop_zone, 1)
        return panel

    def _on_file_selected(self, path: str):
        p = Path(path)
        size = _fmt_size(p.stat().st_size)
        self._log.append_log(f"SYS: File loaded - {p.name} ({size})")
        if self.on_text_command:
            msg = f"[FILE_UPLOADED] path={path} | name={p.name} | size={size}"
            threading.Thread(target=self.on_text_command, args=(msg,), daemon=True).start()

    def _build_logs_panel(self) -> StyledPanel:
        panel = StyledPanel("N.Y.R.O'S LOGS")
        self._log = ChatLogWidget()
        panel.layout.addWidget(self._log)
        return panel

    def _build_controls_panel(self) -> QWidget:
        w = QWidget()
        lay = QVBoxLayout(w)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(10)
        
        btn_style = f"""
            QPushButton {{
                background-color: {C.PANEL};
                color: {C.PRI};
                border: 1px solid {C.BORDER};
                border-radius: 8px;
                padding: 15px;
                font-family: 'Courier New';
                font-weight: bold;
                font-size: 11px;
                text-align: left;
            }}
            QPushButton:hover {{ background-color: {C.PRI_GHO}; }}
        """
        
        remote_btn = QPushButton(" 🖥   REMOTE CONTROL")
        remote_btn.setStyleSheet(btn_style)
        remote_btn.clicked.connect(self._open_remote)
        lay.addWidget(remote_btn)
        
        input_panel = StyledPanel()
        input_panel.setFixedHeight(45)
        input_panel.layout.setContentsMargins(10, 5, 10, 5)
        input_lay = QHBoxLayout()
        input_lay.setContentsMargins(0, 0, 0, 0)
        
        self._input = QLineEdit()
        self._input.setPlaceholderText("Type command...")
        self._input.setStyleSheet(f"background: transparent; color: {C.TEXT}; border: none; font-family: 'Courier New'; font-size: 11px;")
        self._input.returnPressed.connect(self._send)
        
        send_btn = QPushButton("➢")
        send_btn.setStyleSheet(f"color: {C.PRI}; background: transparent; border: none; font-size: 16px;")
        send_btn.setFixedSize(30, 30)
        send_btn.clicked.connect(self._send)
        
        input_lay.addWidget(self._input)
        input_lay.addWidget(send_btn)
        input_panel.layout.addLayout(input_lay)
        lay.addWidget(input_panel)
        
        return w

    def _open_remote(self):
        if not self.on_remote_clicked:
            self._log.append_log("SYS: Dashboard not running — remote unavailable.")
            return
            
        result = self.on_remote_clicked()
        if not result:
            self._log.append_log("SYS: Could not generate remote key.")
            return
            
        url    = result[0]
        key    = result[1]
        auto   = result[2] if len(result) >= 3 else ""
        manual = result[3] if len(result) >= 4 else url

        if getattr(self, '_remote_overlay', None):
            self._remote_overlay._do_close()

        cw  = self.centralWidget()
        ov  = RemoteKeyOverlay(url, key, auto_login_url=auto, manual_url=manual, expiry_secs=600, parent=cw)
        ov.set_new_key_callback(self.on_remote_clicked)
        
        ow, oh = 400, 465
        ov.setGeometry((cw.width() - ow) // 2, (cw.height() - oh) // 2, ow, oh)
        ov.closed.connect(lambda: setattr(self, '_remote_overlay', None))
        ov.show()
        self._remote_overlay = ov
        self._log.append_log(f"SYS: Remote key generated — manual: {manual or url}")

    def notify_phone_connected(self):
        if getattr(self, '_remote_overlay', None) and self._remote_overlay.isVisible():
            self._remote_overlay.mark_connected()

    def _update_metrics(self):
        snap = _metrics.snapshot()
        self.bar_cpu.set_value(snap["cpu"])
        self.bar_ram.set_value(snap["mem"])
        self.bar_disk.set_value(snap["disk"])
        self.bar_health.set_value(98.5)
        self.net_lbl.setText(f"NETWORK             {snap['net']:.1f} KB/s")
        
        tmp = snap.get("tmp", -1.0)
        tmp_str = f"{tmp:.1f} °C" if tmp > 0 else "N/A"
        self.temp_lbl.setText(f"CORE TEMP           {tmp_str}")
        
        t = time.localtime()
        self.clock_lbl.setText(time.strftime("%H:%M:%S", t))
        self.date_lbl.setText(time.strftime("%A, %d %b %Y", t).upper())
        
        try:
            boot_t = psutil.boot_time()
            el = int(time.time() - boot_t)
            h = el // 3600
            m = (el % 3600) // 60
            s = el % 60
            self.uptime_lbl.setText(f"⏱ UPTIME            {h:02d}:{m:02d}:{s:02d}")
        except:
            pass

    def _send(self):
        txt = self._input.text().strip()
        if not txt: return
        self._input.clear()
        self._log.append_log(f"You: {txt}")
        
        
        
        

    # Call this setup inside your UI's __init__ method!
    def setup_weather_bridge(self):
        self.weather_bridge = WeatherSignalBridge()
        self.weather_bridge.weather_ready.connect(self._safe_render_weather_widget)

    def show_weather_widget(self, location, temp, feels, humidity, condition):
        """Thread-safe trigger that routes data through the Qt Signal."""
        if not hasattr(self, 'weather_bridge'):
            self.setup_weather_bridge()
        # Securely emit the data to the main thread
        self.weather_bridge.weather_ready.emit(location, temp, feels, humidity, condition)

    def _safe_render_weather_widget(self, location, temp, feels, humidity, condition):
        """Forces a beautiful, floating Windows-style atmospheric HUD."""
        
        try:
            from PyQt6.QtCore import Qt, QTimer
            from PyQt6.QtWidgets import QLabel, QDialog
            flags = Qt.WindowType.Tool | Qt.WindowType.FramelessWindowHint | Qt.WindowType.WindowStaysOnTopHint
            translucent = Qt.WidgetAttribute.WA_TranslucentBackground
        except ImportError:
            from PyQt6.QtCore import Qt, QTimer
            from PyQt6.QtWidgets import QLabel, QDialog
            flags = Qt.Tool | Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint
            translucent = Qt.WA_TranslucentBackground

        if not hasattr(self, 'weather_popup') or self.weather_popup is None:
            self.weather_popup = QDialog(self)
            self.weather_popup.setWindowFlags(flags)
            self.weather_popup.setAttribute(translucent)
            self.weather_label = QLabel(self.weather_popup)
            
        # Styling matching the dark atmospheric sky-blue gradient
        self.weather_label.setStyleSheet("""
            QLabel {
                background: qlineargradient(x1:0, y1:0, x2:0, y2:1, stop:0 #1b354d, stop:0.4 #162a3d, stop:1 #0f1c29);
                color: white;
                border-radius: 14px;
                padding: 22px;
                font-family: 'Segoe UI', -apple-system, Arial, sans-serif;
                border: 1px solid rgba(255, 255, 255, 0.15);
            }
        """)
        
        # Condition icon parser
        cond_lower = condition.lower()
        icon = "☀️"
        rain_alert = "Enjoy the clear skies today."
        
        if "cloud" in cond_lower or "mist" in cond_lower or "overcast" in cond_lower or "haze" in cond_lower: 
            icon = "⛅"
            rain_alert = "Cloudy overhead. Keep an eye out."
        if "rain" in cond_lower or "shower" in cond_lower or "drizzle" in cond_lower: 
            icon = "🌙" if "night" in cond_lower else "🌦️"
            rain_alert = "Raining right now. Carry an umbrella."
        if "storm" in cond_lower or "thunder" in cond_lower: 
            icon = "⛈️"
            rain_alert = "Thunderstorms detected in your region."

        # HTML Layout mimicking the Windows 11 style widget
        html = f"""
        <table width='340' cellspacing='0' cellpadding='0' style='color: white;'>
            <tr>
                <td colspan='2' style='font-size: 15px; font-weight: 600; padding-bottom: 12px; color: rgba(255,255,255,0.95);'>
                    📍 {location.upper()} <span style='font-size: 10px; color: rgba(255,255,255,0.5); vertical-align: middle;'> ∨</span>
                </td>
            </tr>
            <tr>
                <td valign='middle' style='font-size: 58px; font-weight: 300; letter-spacing: -1px; padding-right: 10px; width: 55%;'>
                    <span style='font-size: 42px; vertical-align: middle;'>{icon}</span> {temp}<span style='font-size: 26px; vertical-align: super; font-weight: 400;'>°C</span>
                </td>
                <td valign='middle' style='font-size: 12px; line-height: 1.4; color: rgba(255,255,255,0.85); width: 45%;'>
                    <div style='font-weight: 600; font-size: 13px; color: #7cbbf2; margin-bottom: 2px;'>💧 Humid: {humidity}%</div>
                    <div style='font-size: 13px; font-weight: 500; color: #ffffff;'>{condition.capitalize()}</div>
                    <div style='font-size: 11px; color: rgba(255,255,255,0.5);'>Feels like {feels}°C</div>
                </td>
            </tr>
            <tr>
                <td colspan='2' style='font-size: 11px; color: rgba(255,255,255,0.6); padding-top: 15px; border-top: 1px solid rgba(255,255,255,0.08); margin-top: 10px;'>
                    💬 Status: <span style='color: #ffffff; font-weight: 500;'>{rain_alert}</span>
                </td>
            </tr>
        </table>
        """
        
        self.weather_label.setText(html)
        self.weather_label.adjustSize()
        self.weather_popup.resize(self.weather_label.size())
        
        # Position popup safely on screen
        geo = self.geometry()
        x = geo.x() + (geo.width() - self.weather_popup.width()) // 2
        y = geo.y() + (geo.height() - self.weather_popup.height()) // 2 + 80
        self.weather_popup.move(x, y)
        
        self.weather_popup.show()
        self.weather_popup.raise_()
        
        QTimer.singleShot(10000, self.weather_popup.hide)
        
    def _on_state_change(self, state: str):
        self.hud.state = state
        self.hud.speaking = (state == "SPEAKING")
        self.phone_booth.set_state(state, self._muted)

    def _toggle_mute(self):
        self._muted = not self._muted
        self.hud.muted = self._muted
        self.phone_booth.set_state("MUTED" if self._muted else "LISTENING", self._muted)
        
class _RootShim:
    def __init__(self, app: QApplication):
        self._app = app
    def mainloop(self):
        self._app.exec()
    def protocol(self, *_):
        pass

class NYROUI:
    def __init__(self, app: QApplication, face_path: str, size=None):
        self._app = app
        self._app.setStyle("Fusion")
        self._win = MainWindow(face_path)
        self._win.show()
        self.root = _RootShim(self._app)
        
    @property
    def muted(self) -> bool:
        return self._win._muted

    @muted.setter
    def muted(self, v: bool):
        if v != self._win._muted:
            self._win._toggle_mute()

    @property
    def current_file(self) -> str | None:
        return self._win._drop_zone.current_file()

    @property
    def on_text_command(self):
        return self._win.on_text_command

    @on_text_command.setter
    def on_text_command(self, cb):
        self._win.on_text_command = cb

    @property
    def on_remote_clicked(self):
        return self._win.on_remote_clicked

    @on_remote_clicked.setter
    def on_remote_clicked(self, cb):
        self._win.on_remote_clicked = cb

    def notify_phone_connected(self) -> None:
        self._win.notify_phone_connected()

    def set_state(self, state: str):
        self._win._state_sig.emit(state)

    def write_log(self, text: str):
        self._win._log.append_log(text)

    def wait_for_api_key(self):
        while not self._win._ready:
            time.sleep(0.1)

    def start_speaking(self):
        self.set_state("SPEAKING")

    def stop_speaking(self):
        if not self.muted:
            self.set_state("LISTENING")