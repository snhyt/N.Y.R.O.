import webbrowser
import urllib.parse
import urllib.request
import re
import time

try:
    import pyautogui
except ImportError:
    pyautogui = None

def skip_youtube_ad() -> str:
    if not pyautogui:
        return "pyautogui is not installed."
    
    try:
        from actions.computer_control import smart_vision_click
        res = smart_vision_click("Skip Ad button")
        if "Located and clicked" in res:
            return "Skipped YouTube ad via visual AI recognition."
    except Exception:
        pass
    
    try:
        sw, sh = pyautogui.size()
        pyautogui.moveTo(int(sw * 0.88), int(sh * 0.82), duration=0.2)
        pyautogui.click()
        time.sleep(0.4)
        
        pyautogui.press('tab')
        time.sleep(0.1)
        pyautogui.press('enter')
        return "Executed automated skip ad sequence."
    except Exception as e:
        return f"Failed to skip ad: {e}"

def youtube_video(parameters: dict, response=None, player=None) -> str:
    action = parameters.get("action", "play").lower().strip()
    query = parameters.get("query", "bansuri performance")
    
    if player:
        player.write_log(f"[YouTube] Executing action: {action}")

    if action in ("skip", "skip_ad", "skip_ads"):
        return skip_youtube_ad()
        
    elif action == "play":
        try:
            search_url = f"https://www.youtube.com/results?search_query={urllib.parse.quote(query)}"
            req = urllib.request.Request(search_url, headers={'User-Agent': 'Mozilla/5.0'})
            html = urllib.request.urlopen(req).read().decode('utf-8')
            video_ids = re.findall(r"watch\?v=(\S{11})", html)
            
            if video_ids:
                direct_url = f"https://www.youtube.com/watch?v={video_ids[0]}"
                webbrowser.open(direct_url)
                return f"Playing top YouTube result for: {query}."
        except Exception:
            pass
            
        url = f"https://www.youtube.com/results?search_query={urllib.parse.quote(query)}"
        webbrowser.open(url)
        return f"Opening YouTube results for: {query}."
        
    elif action == "trending":
        webbrowser.open("https://www.youtube.com/feed/trending")
        return "Opening YouTube trending page."
        
    return "YouTube matrix updated."