import os
import time
import urllib.parse
from pathlib import Path

try:
    import ctypes
    from ctypes import wintypes
    import pyautogui
    import pyperclip
    import pygetwindow as gw
except ImportError:
    pass

class DROPFILES(ctypes.Structure):
    _fields_ = [
        ("pFiles", wintypes.DWORD),
        ("pt", wintypes.POINT),
        ("fNC", wintypes.BOOL),
        ("fWide", wintypes.BOOL),
    ]

def copy_file_to_clipboard(filepath: str):
    abs_path = os.path.abspath(filepath)
    offset = ctypes.sizeof(DROPFILES)
    length = len(abs_path) + 2
    size = offset + length * 2

    buf = (ctypes.c_char * size)()
    df = DROPFILES.from_buffer(buf)
    df.pFiles = offset
    df.fWide = True

    for i, c in enumerate(abs_path):
        buf[offset + i * 2] = ord(c) & 0xFF
        buf[offset + i * 2 + 1] = (ord(c) >> 8) & 0xFF

    user32 = ctypes.windll.user32
    kernel32 = ctypes.windll.kernel32

    user32.OpenClipboard(0)
    user32.EmptyClipboard()
    hGlobal = kernel32.GlobalAlloc(0x0042, size)
    pGlobal = kernel32.GlobalLock(hGlobal)
    ctypes.memmove(pGlobal, buf, size)
    kernel32.GlobalUnlock(hGlobal)
    user32.SetClipboardData(15, hGlobal)
    user32.CloseClipboard()

def _resolve_attachment_path(raw_path: str) -> str | None:
    if not raw_path:
        return None
    clean_path = raw_path.strip().replace('"', '').replace("'", "").replace('\\', os.sep).replace('/', os.sep)
    if os.path.exists(clean_path):
        return os.path.abspath(clean_path)
        
    search_name = Path(clean_path).name.lower()
    home = Path.home()
    onedrive = home / "OneDrive"
    
    search_dirs = [
        onedrive / "Downloads", home / "Downloads",
        onedrive / "Desktop", home / "Desktop",
        onedrive / "Documents", home / "Documents"
    ]
    
    # NEW: Smart detection for generic phrases to grab the latest downloaded file
    if search_name in ["this pdf", "latest pdf", "the pdf", "this file", "latest file"]:
        latest_file = None
        latest_time = 0
        for folder in search_dirs:
            if folder.exists():
                try:
                    for f in folder.iterdir():
                        if f.is_file():
                            # Restrict to PDFs if the user explicitly asked for a PDF
                            if "pdf" in search_name and f.suffix.lower() != ".pdf":
                                continue
                            mtime = f.stat().st_mtime
                            if mtime > latest_time:
                                latest_time = mtime
                                latest_file = f
                except Exception:
                    pass
        if latest_file:
            return str(latest_file.resolve())
            
    # Existing exact and partial match logic
    for folder in search_dirs:
        if not folder.exists():
            continue
        exact_match = folder / search_name
        if exact_match.exists():
            return str(exact_match.resolve())
        try:
            for f in folder.iterdir():
                if f.is_file() and search_name in f.name.lower():
                    return str(f.resolve())
        except Exception:
            pass
    return None
def _focus_whatsapp():
    try:
        wins = gw.getWindowsWithTitle("WhatsApp")
        if wins:
            win = wins[0]
            if win.isMinimized: win.restore()
            win.activate()
            time.sleep(1.2)
            return True
    except Exception:
        pass
    return False

def _launch_whatsapp_safely():
    """Fail-safe launch targeting both store protocols and system shells."""
    try:
        # Try URI protocol first
        os.system('start whatsapp://')
    except Exception:
        # Fail-safe backup for standard Windows 11 Microsoft Store locations
        os.system('start explorer.exe shell:AppsFolder\Microsoft.WhatsApp_8wekyb3d8bbwe!App')

def send_message(parameters: dict, response=None, player=None, session_memory=None):
    receiver = parameters.get("receiver", "").strip()
    message = parameters.get("message_text", "").strip()
    raw_attachment = parameters.get("attachment_path")
    
    attachment = _resolve_attachment_path(raw_attachment) if raw_attachment else None
    
    if player:
        player.write_log(f"SYS: Dispatching WhatsApp automation to {receiver}...")

    if attachment and os.path.isdir(attachment):
        import shutil
        zip_path = f"{attachment}_compressed"
        shutil.make_archive(zip_path, 'zip', attachment)
        attachment = f"{zip_path}.zip"

    clean_phone = "".join(filter(str.isdigit, receiver))
    
    if len(clean_phone) >= 10:
        encoded_msg = urllib.parse.quote(message if not attachment else "")
        os.system(f'start whatsapp://send?phone={clean_phone}&text={encoded_msg}')
        time.sleep(4.5)
        _focus_whatsapp()
        if not attachment and message:
            pyautogui.press('enter')
    else:
        _launch_whatsapp_safely()
        time.sleep(3.5)
        _focus_whatsapp()
        
        pyautogui.hotkey('ctrl', 'f')
        time.sleep(1.0)
        pyperclip.copy(receiver)
        pyautogui.hotkey('ctrl', 'v')
        time.sleep(2.0)
        pyautogui.press('down')
        time.sleep(0.3)
        pyautogui.press('enter')
        time.sleep(1.2)
        
        if message and not attachment:
            pyperclip.copy(message)
            pyautogui.hotkey('ctrl', 'v')
            time.sleep(0.5)
            pyautogui.press('enter')

    if attachment and os.path.exists(attachment):
        abs_path = os.path.abspath(attachment)
        time.sleep(1.0)
        
        if player:
            player.write_log(f"SYS: Dropping physical file payload: {Path(abs_path).name}")
        
        _focus_whatsapp()
        time.sleep(0.5)
        
        copy_file_to_clipboard(abs_path)
        time.sleep(0.8)
        
        # Paste the file into WhatsApp
        pyautogui.hotkey('ctrl', 'v')
        
        # INCREASED WAIT TIME: Give WhatsApp 3.5 seconds to load the file preview window
        time.sleep(3.5)
        
        if message:
            pyperclip.copy(message)
            pyautogui.hotkey('ctrl', 'v')
            time.sleep(0.8)
            
        # THE FIX: Double Enter press to bypass the preview screen and force the send
        pyautogui.press('enter')
        time.sleep(0.5)
        pyautogui.press('enter')
        time.sleep(0.5)
        
        return f"Successfully found and uploaded file ({Path(abs_path).name}) and sent to {receiver}."

    if raw_attachment and not attachment:
        return f"Could not find file matching '{raw_attachment}' inside Downloads, Desktop, or Documents folders."

    return f"Transmitted message to {receiver} successfully."