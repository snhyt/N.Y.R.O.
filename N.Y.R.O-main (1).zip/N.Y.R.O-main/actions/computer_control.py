import io
import json
import platform
import re
import subprocess
import sys
import time
import math
import ctypes
from pathlib import Path

try:
    import pyautogui
    import pygetwindow as gw
    pyautogui.FAILSAFE = True
    pyautogui.PAUSE    = 0.005  
    _PYAUTOGUI = True
except ImportError:
    _PYAUTOGUI = False

def _get_api_key() -> str:
    path = Path(__file__).resolve().parent.parent / "config" / "api_keys.json"
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)["gemini_api_key"]

def slow_click():
    """Forces the OS to register a click by holding the mouse down briefly."""
    pyautogui.mouseDown(button='left')
    time.sleep(0.06)
    pyautogui.mouseUp(button='left')
    time.sleep(0.06)

def move_clean(x, y):
    """Safely lifts the pen, clears OS drag state, and moves cursor."""
    pyautogui.mouseUp(button='left')
    time.sleep(0.015)
    pyautogui.moveTo(x, y)
    time.sleep(0.015)

def draw_circle_clean(center_x, center_y, radius, steps=50):
    start_x = center_x + radius * math.cos(0)
    start_y = center_y + radius * math.sin(0)
    move_clean(start_x, start_y)
    
    for i in range(1, steps + 1):
        angle = i * (2 * math.pi / steps)
        x = center_x + radius * math.cos(angle)
        y = center_y + radius * math.sin(angle)
        pyautogui.dragTo(x, y, duration=0.001, button='left')
    pyautogui.mouseUp(button='left')

def draw_line_clean(x1, y1, x2, y2):
    move_clean(x1, y1)
    pyautogui.dragTo(x2, y2, duration=0.03, button='left')
    pyautogui.mouseUp(button='left')

def force_maximize_paint():
    time.sleep(1.5)
    if not gw:
        return
    for w in gw.getAllWindows():
        if "paint" in w.title.lower() or "untitled" in w.title.lower():
            if w.isMinimized: w.restore()
            ctypes.windll.user32.ShowWindow(w._hWnd, 3)
            w.activate()
            break


        
        
def smart_vision_click(description: str) -> str:
    try:
        from google import genai
        from google.genai import types
        
        sw, sh = pyautogui.size()
        img = pyautogui.screenshot()
        buf = io.BytesIO()
        img.save(buf, format="PNG")
        
        client = genai.Client(api_key=_get_api_key())
        prompt = (
            f"This is a {sw}x{sh} screenshot. Locate the visual UI element described as: '{description}'. "
            f"Reply with ONLY the exact center coordinate as: x,y "
            f"If not found, reply: NOT_FOUND"
        )
        res = client.models.generate_content(
            model="gemini-2.5-flash",
            contents=[types.Part.from_bytes(data=buf.getvalue(), mime_type="image/png"), prompt]
        )
        txt = res.text.strip()
        match = re.search(r"(\d+)\s*,\s*(\d+)", txt)
        if match:
            x, y = int(match.group(1)), int(match.group(2))
            pyautogui.moveTo(x, y, duration=0.3)
            pyautogui.click()
            return f"Located and clicked '{description}' at ({x}, {y})."
        return f"Could not visually locate '{description}' on screen."
    except Exception as e:
        return f"Smart vision click failed: {e}"

def computer_control(parameters: dict, response=None, player=None, session_memory=None) -> str:
    if not _PYAUTOGUI: return "pyautogui not installed."
    params = parameters or {}
    action = params.get("action", "").lower().strip()
    desc = params.get("description", "")

    if player: player.write_log(f"[Computer] {action}")

  
    if action in ["screen_click", "smart_click"]:
        return smart_vision_click(desc)
    if action == "type":
        pyautogui.typewrite(params.get("text", ""), interval=0.03)
        return "Typed text."
    if action == "click":
        pyautogui.click(params.get("x"), params.get("y"))
        return "Clicked coordinate."

    return f"Unknown control action: '{action}'"