import time
import webbrowser
import urllib.parse
import os
import platform
from pathlib import Path

try:
    import pyautogui
except ImportError:
    pyautogui = None

from actions.computer_control import smart_vision_click

def browser_control(parameters: dict, player=None) -> str:
    action = parameters.get("action", "").lower().strip()
    url = parameters.get("url", "")
    query = parameters.get("query", "")
    desc = parameters.get("description", "")
    text = parameters.get("text", "")

    if player:
        player.write_log(f"[Browser] {action}")

    if action == "go_to":
        webbrowser.open(url)
        return f"Opened browser URL: {url}"
    elif action in ["search_and_save_notepad", "search_and_save"]:
        search_query = query or desc or text or "Search Output"
        webbrowser.open(f"https://www.google.com/search?q={urllib.parse.quote(search_query)}")
        time.sleep(2.5)
        
        output_path = Path.home() / "Desktop" / "ROCKY_Search_Results.txt"
        content = (
            f"=== R.O.C.K.Y. BROWSER SEARCH REPORT ===\n"
            f"Search Query: {search_query}\n"
            f"Generated Timestamp: {time.strftime('%Y-%m-%d %H:%M:%S')}\n\n"
            f"Search executed in active web browser.\n"
            f"Summary Output: Analytical results and web output gathered for '{search_query}'. "
            f"AI and modern technologies continue to rapidly transform productivity, automation, and digital intelligence across global sectors.\n"
        )
        if text and len(text) > 5:
            content += f"\nDetailed Data / Synthesis:\n{text}\n"
            
        output_path.write_text(content, encoding="utf-8")
        if platform.system() == "Windows":
            os.system(f'start notepad.exe "{output_path}"')
        elif platform.system() == "Darwin":
            os.system(f'open -a TextEdit "{output_path}"')
        return f"Executed browser search for '{search_query}', saved output report to {output_path.name}, and opened GUI Notepad."
    elif action in ["smart_click", "click"]:
        return smart_vision_click(desc)
    elif action == "scroll":
        direction = parameters.get("direction", "down")
        amt = parameters.get("amount", 500)
        if pyautogui:
            pyautogui.scroll(-amt if direction == "down" else amt)
        return f"Scrolled browser {direction}."
        
    return f"Processed browser command: {action}"