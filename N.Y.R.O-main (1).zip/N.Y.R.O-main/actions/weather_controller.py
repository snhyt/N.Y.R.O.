import requests

def weather_controller(parameters: dict, player=None) -> str:
    """Fetches live weather data and routes safely to the MainWindow instance."""
    
    location = parameters.get("location") or parameters.get("city") or "Mumbai"
    location = location.strip()
    
    if player:
        player.write_log(f"[Weather] Fetching live reporting for {location}...")
        
    try:
        res = requests.get(f"https://wttr.in/{location}?format=j1", timeout=6)
        if res.status_code == 200:
            data = res.json()
            current = data['current_condition'][0]
            temp_c = current['temp_C']
            desc = current['weatherDesc'][0]['value']
            feels_like = current['FeelsLikeC']
            humidity = current['humidity']
            
            # CRITICAL FIX: Direct object reference resolution
            # If player is the ROCKYUI wrapper, dig out the real _win (MainWindow) inside it
            target_ui = player._win if hasattr(player, '_win') else player
            
            if target_ui and hasattr(target_ui, 'show_weather_widget'):
                target_ui.show_weather_widget(location, temp_c, feels_like, humidity, desc)
                return f"Success. Weather HUD template for {location} is now live on screen."
            else:
                return "Error: Could not find show_weather_widget on UI instance."
        else:
            return f"Failed to retrieve weather metrics for {location}."
    except Exception as e:
        return f"Weather engine error: {e}"