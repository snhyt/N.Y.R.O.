import os
import shutil
import platform
import subprocess
from pathlib import Path

_OS = platform.system()

def _resolve_shortcut(path_str: str) -> Path:
    """Intelligently locates folders, handling sub-paths and OneDrive redirections."""
    p = path_str.strip().replace('\\', '/')
    p_lower = p.lower()
    home = Path.home()
    onedrive = home / "OneDrive"
    
    def get_dir(name):
        return onedrive / name if (onedrive / name).exists() else home / name

    # Exact matches
    if p_lower in ("downloads", "home/downloads"): return get_dir("Downloads")
    if p_lower in ("desktop", "home/desktop"): return get_dir("Desktop")
    if p_lower in ("documents", "home/documents"): return get_dir("Documents")
    
    # NEW: Handle sub-paths (e.g., "downloads/video project 3")
    if p_lower.startswith("downloads/"): return get_dir("Downloads") / p[10:]
    if p_lower.startswith("desktop/"): return get_dir("Desktop") / p[8:]
    if p_lower.startswith("documents/"): return get_dir("Documents") / p[10:]
    
    if p_lower in ("home", "~"): return home
    return Path(path_str).expanduser().resolve()


def file_controller(parameters: dict, player=None) -> str:
    action = parameters.get("action", "").lower().strip()
    raw_path = parameters.get("path", "").strip()
    content = parameters.get("content", "")
    name = parameters.get("name", "")

    if player:
        player.write_log(f"[FileController] Executing action: {action}")

    try:
        if action in ("open_explorer", "explorer"):
            target_path = _resolve_shortcut(raw_path) if raw_path else Path.home()
            if not target_path.exists():
                return f"Path does not exist: {target_path}"
            if _OS == "Windows":
                subprocess.Popen(f'explorer "{target_path}"')
            elif _OS == "Darwin":
                subprocess.Popen(["open", str(target_path)])
            else:
                subprocess.Popen(["xdg-open", str(target_path)])
            return f"Physically opened GUI File Explorer at: {target_path}"

        if action == "open":
            target_path = _resolve_shortcut(raw_path)
            if not target_path.exists():
                return f"File does not exist: {target_path}"
            if _OS == "Windows":
                os.startfile(str(target_path))
            elif _OS == "Darwin":
                subprocess.Popen(["open", str(target_path)])
            else:
                subprocess.Popen(["xdg-open", str(target_path)])
            return f"Launched file GUI: {target_path.name}"

        if action == "list":
            target_path = _resolve_shortcut(raw_path) if raw_path else Path.home()
            if not target_path.exists():
                return f"Directory not found: {target_path}"
            items = os.listdir(target_path)
            files = [f for f in items if (target_path / f).is_file()][:15]
            dirs = [d for d in items if (target_path / d).is_dir()][:10]
            return f"Contents of {target_path.name}: {len(dirs)} folders, {len(files)} files. Top files: {', '.join(files[:8])}"

        if action == "create_file":
            target_path = _resolve_shortcut(raw_path)
            target_path.parent.mkdir(parents=True, exist_ok=True)
            target_path.write_text(content, encoding="utf-8")
            return f"Created file: {target_path}"

        if action == "create_folder":
            target_path = _resolve_shortcut(raw_path)
            target_path.mkdir(parents=True, exist_ok=True)
            return f"Created directory: {target_path}"

        if action == "delete":
            target_path = _resolve_shortcut(raw_path)
            
            # THE FIX: If the exact file is missing, do a fuzzy search in the folder 
            # to catch files where you didn't specify the extension (like .mp4 or .jpg)
            if not target_path.exists():
                parent_dir = target_path.parent
                search_name = target_path.name.lower()
                
                if parent_dir.exists() and parent_dir.is_dir():
                    for f in parent_dir.iterdir():
                        if search_name in f.name.lower():
                            target_path = f
                            break
                            
            if not target_path.exists():
                return f"Cannot delete. File or folder not found: {target_path}"
            
            try:
                if target_path.is_file():
                    target_path.unlink()
                    return f"Deleted file: {target_path.name}"
                else:
                    import shutil
                    shutil.rmtree(target_path)
                    return f"Deleted folder and its contents: {target_path.name}"
            except Exception as e:
                return f"Failed to delete {target_path.name}: {e}"
        if action in ("empty_recycle_bin", "clean_recycle_bin", "clean_bin"):
            if _OS == "Windows":
                import ctypes
                # Uses native Windows API. 7 = No Confirmation + No UI + No Sound
                result = ctypes.windll.shell32.SHEmptyRecycleBinW(None, None, 7)
                if result == 0:
                    return "Successfully emptied the Recycle Bin."
                else:
                    return "The Recycle Bin is already empty."
            return "Emptying the Recycle Bin is only supported on Windows."
        

        if action == "read":
            target_path = _resolve_shortcut(raw_path)
            if not target_path.exists(): return f"File not found: {target_path}"
            txt = target_path.read_text(encoding="utf-8")
            return f"Read {len(txt)} chars from {target_path.name}. Preview: {txt[:200]}..."

        if action == "find":
            search_dir = _resolve_shortcut(raw_path) if raw_path else Path.home()
            matches = list(search_dir.rglob(f"*{name}*"))[:10]
            if not matches: return f"No files found matching '{name}' in {search_dir}"
            return f"Found {len(matches)} matches. Top locations: {', '.join([str(m) for m in matches[:3]])}"

        if action in ("write_and_open_notepad", "save_and_open", "write_and_open"):
            target_path = _resolve_shortcut(raw_path) if raw_path else (Path.home() / "Desktop" / "ROCKY_Output.txt")
            if target_path.suffix != ".txt":
                target_path = target_path.with_suffix(".txt")
            target_path.parent.mkdir(parents=True, exist_ok=True)
            target_path.write_text(content, encoding="utf-8")
            if _OS == "Windows":
                subprocess.Popen(f'notepad.exe "{target_path}"')
            elif _OS == "Darwin":
                subprocess.Popen(["open", "-a", "TextEdit", str(target_path)])
            else:
                subprocess.Popen(["xdg-open", str(target_path)])
            return f"Successfully saved text to {target_path.name} and opened GUI Notepad."

        return f"Processed file command: {action}"

    except Exception as e:
        return f"File controller failure: {e}"