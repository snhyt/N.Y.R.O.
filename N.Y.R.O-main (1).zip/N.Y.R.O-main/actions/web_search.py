import webbrowser
import urllib.parse

def web_search(parameters: dict, player=None) -> str:
    query = parameters.get("query", "latest social media algorithm updates to improve channel reach")
    url = f"https://www.google.com/search?q={urllib.parse.quote(query)}"
    webbrowser.open(url)
    return f"Searching the web for: {query}."