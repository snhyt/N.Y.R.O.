import webbrowser
import urllib.parse

def maps_controller(parameters: dict, player=None) -> str:
    """Handles Google Maps navigation routing with auto-navigate flags."""
    action = parameters.get("action", "").lower().strip()
    
    if action == "navigate":
        origin = parameters.get("origin", "").strip()
        destination = parameters.get("destination", "").strip()
        mode = parameters.get("mode", "driving").lower().strip()

        if not destination:
            return "Failed: A destination is required for navigation."

        if mode in ["bike", "motorcycle", "scooter", "bicycling"]:
            g_mode = "bicycling"
        elif mode in ["walk", "walking", "foot"]:
            g_mode = "walking"
        elif mode in ["transit", "bus", "train", "metro"]:
            g_mode = "transit"
        else:
            g_mode = "driving"

        base_url = "https://www.google.com/maps/dir/?api=1"
        dest_encoded = urllib.parse.quote(destination)
        
        # dir_action=navigate forces mobile apps to start turn-by-turn tracking instantly
        url = f"{base_url}&destination={dest_encoded}&travelmode={g_mode}&dir_action=navigate"
        
        if origin and origin.lower() not in ["current location", "here", "my location", "mumbai"]:
            orig_encoded = urllib.parse.quote(origin)
            url += f"&origin={orig_encoded}"

        webbrowser.open(url)
        return f"Navigation initiated to {destination} via {mode}."

    return f"Unknown maps action: {action}"