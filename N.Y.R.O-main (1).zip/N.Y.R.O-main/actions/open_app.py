import os
import time
import platform
import subprocess

try:
    import pygetwindow as gw
except ImportError:
    gw = None

_OS = platform.system()

APP_MAP = {
    "notepad": "notepad.exe",
    "chrome": "start chrome",
    "google chrome": "start chrome",
    "edge": "start msedge",
    "microsoft edge": "start msedge",
    "file explorer": "explorer.exe",
    "explorer": "explorer.exe",
    "paint": "mspaint.exe",
    "calculator": "calc.exe",
    "vs code": "code",
    "vscode": "code",
    "command prompt": "cmd.exe",
    "cmd": "cmd.exe"
}

def open_app(parameters: dict, response=None, player=None) -> str:
    app_name = parameters.get("app_name", "").lower().strip()
    
    if player:
        player.write_log(f"[OpenApp] Launching GUI application: {app_name}")

    try:
        cmd = APP_MAP.get(app_name)
        if cmd:
            os.system(cmd)
            time.sleep(1.5)
            if gw:
                try:
                    wins = gw.getWindowsWithTitle(app_name.split()[0])
                    if wins:
                        if wins[0].isMinimized: wins[0].restore()
                        wins[0].activate()
                except Exception:
                    pass
            return f"Successfully launched GUI application: {app_name}"

        if _OS == "Windows":
            os.system(f'start "" "{app_name}"')
        elif _OS == "Darwin":
            subprocess.Popen(["open", "-a", app_name])
        else:
            subprocess.Popen([app_name])
            
        time.sleep(1.5)
        return f"Launched desktop application: {app_name}"

    except Exception as e:
        return f"Failed to open application '{app_name}': {e}"