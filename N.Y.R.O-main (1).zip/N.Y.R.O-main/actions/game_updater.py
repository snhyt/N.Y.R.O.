def game_updater(parameters: dict, player=None, speak=None) -> str:
    game = parameters.get("game_name", "Stumble Guys")
    platform_name = parameters.get("platform", "steam")
    action = parameters.get("action", "update")
    
    return f"Initiating {action} protocols for {game} on {platform_name}."