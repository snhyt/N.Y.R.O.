import urllib.request
import urllib.parse

def weather_action(parameters: dict, player=None) -> str:
    city = parameters.get("city", "")
    if not city: 
        return "City required for weather."
    
    try:
        url = f"https://wttr.in/{urllib.parse.quote(city)}?format=%C+%t"
        req = urllib.request.Request(url, headers={'User-Agent': 'Mozilla/5.0'})
        weather = urllib.request.urlopen(req).read().decode('utf-8')
        return f"The weather in {city} is currently {weather}."
    except Exception as e:
        return f"Weather systems offline: {e}"