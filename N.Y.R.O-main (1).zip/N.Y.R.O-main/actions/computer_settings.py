import json
import re
import sys
import time
import subprocess
import platform
from pathlib import Path

try:
    import pyautogui
    import pygetwindow as gw
    pyautogui.FAILSAFE = True
    pyautogui.PAUSE    = 0.05
    _PYAUTOGUI = True
except ImportError:
    _PYAUTOGUI = False

_OS = platform.system()

def volume_up(amount: int = 5):
    if _OS == "Windows":
        for _ in range(amount): pyautogui.press("volumeup")
    elif _OS == "Darwin":
        subprocess.run(["osascript", "-e", f"set volume output volume (output volume of (get volume settings) + {amount*2})"], capture_output=True)

def volume_down(amount: int = 5):
    if _OS == "Windows":
        for _ in range(amount): pyautogui.press("volumedown")
    elif _OS == "Darwin":
        subprocess.run(["osascript", "-e", f"set volume output volume (output volume of (get volume settings) - {amount*2})"], capture_output=True)

def volume_mute():
    pyautogui.press("volumemute")

def execute_window_arrangement(description: str = "", action: str = "") -> str:
    """Perfectly divides the screen into 2 halves or 4 quadrants based on the user's request."""
    if _OS != "Windows":
        return "Exact window snapping is natively supported on Windows only."
    try:
        sw, sh = pyautogui.size()
        half_w = sw // 2
        half_h = sh // 2
        
        # 1. Gather all legitimate application windows
        all_wins = [w for w in gw.getAllWindows() if w.title and w.visible and w.width > 0 and w.height > 0]
        valid_wins = [w for w in all_wins if "R.O.C.K.Y" not in w.title and "Program Manager" not in w.title and "Settings" not in w.title and "Taskbar" not in w.title]
        
        # 2. Minimize ROCKY dashboard out of the way
        for w in all_wins:
            if "R.O.C.K.Y" in w.title and not w.isMinimized:
                w.minimize()

        desc_lower = description.lower()
        is_quad = "4" in desc_lower or "four" in desc_lower or "quad" in desc_lower or action == "quad"
        
        # ==========================================
        # 4-WAY SPLIT LOGIC (QUADRANTS)
        # ==========================================
        if is_quad:
            if len(valid_wins) < 4:
                return f"You need at least 4 open application windows to perform a quad split. Only found {len(valid_wins)}."
            
            targets = valid_wins[:4]
            coords = [
                (0, 0, half_w, half_h),           
                (half_w, 0, half_w, half_h),      
                (0, half_h, half_w, half_h),      
                (half_w, half_h, half_w, half_h)  
            ]
            
            for i, w in enumerate(targets):
                if w.isMaximized: w.restore()
                w.activate()
                time.sleep(0.1)
                x, y, width, height = coords[i]
                w.moveTo(x, y)
                w.resizeTo(width, height)
            
            names = [w.title[:10] for w in targets]
            return f"Successfully arranged 4 apps into quadrants: {', '.join(names)}."
            
        # ==========================================
        # 2-WAY SPLIT LOGIC (LEFT & RIGHT)
        # ==========================================
        else:
            if len(valid_wins) < 2:
                return f"Need at least 2 open application windows for split screen. Only found {len(valid_wins)}."

            desc_clean = re.sub(r'\b(split|screen|between|and|put|the|on|left|right|side|arrange|with|app)\b', '', desc_lower).strip()
            keywords = [kw for kw in desc_clean.split() if len(kw) > 1]

            matched_wins = []
            for kw in keywords:
                for w in valid_wins:
                    if kw in w.title.lower() and w not in matched_wins:
                        matched_wins.append(w)
                        break

            left_win = matched_wins[0] if len(matched_wins) > 0 else valid_wins[0]
            right_win = matched_wins[1] if len(matched_wins) > 1 else (valid_wins[1] if valid_wins[1] != left_win else valid_wins[0])

            if "left" in desc_lower or "right" in desc_lower:
                for w in matched_wins:
                    title_l = w.title.lower()
                    for kw in keywords:
                        if kw in title_l:
                            app_word_idx = desc_lower.find(kw)
                            left_idx = desc_lower.find("left")
                            right_idx = desc_lower.find("right")
                            
                            if left_idx != -1 and abs(app_word_idx - left_idx) < 20:
                                left_win = w
                            elif right_idx != -1 and abs(app_word_idx - right_idx) < 20:
                                right_win = w

            if left_win == right_win and len(valid_wins) >= 2:
                right_win = valid_wins[1] if valid_wins[0] == left_win else valid_wins[0]

            if left_win.isMaximized: left_win.restore()
            left_win.activate()
            time.sleep(0.1)
            left_win.moveTo(0, 0)
            left_win.resizeTo(half_w, sh)
            
            if right_win.isMaximized: right_win.restore()
            right_win.activate()
            time.sleep(0.1)
            right_win.moveTo(half_w, 0)
            right_win.resizeTo(half_w, sh)

            return f"Perfectly aligned '{left_win.title[:15]}' to the Left and '{right_win.title[:15]}' to the Right."

    except Exception as e:
        return f"Split screen layout execution error: {e}"

def computer_settings(parameters: dict = None, response=None, player=None, session_memory=None) -> str:
    if not _PYAUTOGUI:
        return "pyautogui is not installed."

    params     = parameters or {}
    raw_action = params.get("action", "").strip().lower()
    desc       = params.get("description", "")
    amount     = params.get("amount", 5)

    if player:
        player.write_log(f"[Settings] {raw_action}")

    # Window Management
    if raw_action in ["split", "split_screen", "arrange", "quad"]:
        return execute_window_arrangement(desc, raw_action)

    # Volume & Media Management (Bluetooth Speakers)
    if raw_action == "volume_up":
        volume_up(amount)
        return f"Increased PC/Bluetooth volume by {amount} steps."
    if raw_action == "volume_down":
        volume_down(amount)
        return f"Decreased PC/Bluetooth volume by {amount} steps."
    if raw_action == "mute":
        volume_mute()
        return "Toggled PC/Bluetooth mute."
    
    if raw_action == "media_play_pause":
        pyautogui.press("playpause")
        return "Toggled play/pause on the Bluetooth speaker."
    if raw_action == "media_next":
        pyautogui.press("nexttrack")
        return "Skipped to the next track on the Bluetooth speaker."
    if raw_action == "media_prev":
        pyautogui.press("prevtrack")
        return "Returned to the previous track on the Bluetooth speaker."

    # Bluetooth Hardware Control
    if raw_action == "bluetooth_settings":
        if _OS == "Windows":
            subprocess.Popen(["cmd", "/c", "start", "ms-settings:bluetooth"])
            return "Opened Windows Bluetooth settings. You can switch your speaker on/off or pair a new one here."
        return "Bluetooth settings automation is for Windows only."

    return f"Unknown settings action: {raw_action}"