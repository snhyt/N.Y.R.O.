import io
import json
from pathlib import Path
from PIL import Image

try:
    import pyautogui
except ImportError:
    pyautogui = None

def _get_api_key() -> str:
    path = Path(__file__).resolve().parent.parent / "config" / "api_keys.json"
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)["gemini_api_key"]

def screen_process(parameters: dict, response=None, player=None, session_memory=None) -> str:
    text = parameters.get("text", "Analyze what is currently visible on my screen.")
    angle = parameters.get("angle", "screen").lower()
    
    if player:
        player.set_state("PROCESSING")
        player.write_log(f"SYS: Capturing visual frame ({angle}) for analysis...")

    try:
        if angle == "camera":
            import cv2
            cap = cv2.VideoCapture(0)
            ret, frame = cap.read()
            cap.release()
            if not ret:
                return "Error: Could not access camera frame."
            img = Image.fromarray(cv2.cvtColor(frame, cv2.COLOR_BGR2RGB))
        else:
            if not pyautogui:
                return "Error: pyautogui module not installed."
            img = pyautogui.screenshot()
            
        img.thumbnail((1280, 720))
        buffer = io.BytesIO()
        img.save(buffer, format="PNG")
        
        from google import genai
        from google.genai import types
        
        client = genai.Client(api_key=_get_api_key())
        prompt = f"Look at this screenshot and answer concisely: {text}"
        
        res = client.models.generate_content(
            model="gemini-2.5-flash",
            contents=[types.Part.from_bytes(data=buffer.getvalue(), mime_type="image/png"), prompt]
        )
        
        analysis = res.text.strip()
        if player:
            player.write_log(f"SYS: Vision analysis complete.")
            
        return f"Vision module analyzed screen. Analysis: {analysis}"
    except Exception as e:
        return f"Vision module failure: {e}"