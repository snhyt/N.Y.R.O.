import webbrowser

def flight_finder(parameters: dict, player=None) -> str:
    origin = parameters.get("origin", "")
    destination = parameters.get("destination", "")
    date = parameters.get("date", "")
    
    url = f"https://www.google.com/travel/flights?q=Flights+from+{origin}+to+{destination}+on+{date}"
    webbrowser.open(url)
    return f"Displaying flight configurations from {origin} to {destination}."