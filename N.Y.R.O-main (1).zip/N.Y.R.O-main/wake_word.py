import time
import threading
import speech_recognition as sr

class WakeWordListener(threading.Thread):
    def __init__(self, wake_signal, wake_phrases=None):
        super().__init__(daemon=True)
        self.wake_signal = wake_signal
        self.wake_phrases = wake_phrases or [
            "wake up nyro", "hey nyro", "nyro wake up", 
            "come online nyro", "hi nyro", "hello nyro", "nyro"
        ]
        self.running = True

    def run(self):
        recognizer = sr.Recognizer()
        recognizer.pause_threshold = 0.5
        recognizer.dynamic_energy_threshold = False
        recognizer.energy_threshold = 300

        try:
            with sr.Microphone() as source:
                print("\n[WakeWord] 🟢 Listening for 'Nyro'...\n")
                
                while self.running:
                    try:
                        audio = recognizer.listen(source, timeout=1.0, phrase_time_limit=3.0)
                        text = recognizer.recognize_google(audio).lower()
                        print(f"[WakeWord] Heard: '{text}'")
                        
                        for phrase in self.wake_phrases:
                            if phrase in text:
                                print("⚡ [WakeWord] WAKING UP NYRO!")
                                # Emit the signal to trigger the UI function
                                self.wake_signal.emit()
                                time.sleep(3)  # Cooldown to prevent spam
                                break
                                
                    except sr.WaitTimeoutError:
                        continue
                    except sr.UnknownValueError:
                        continue
                    except Exception:
                        time.sleep(0.1)
                        
        except Exception as e:
            print(f"❌ [WakeWord] Mic error: {e}")

    def stop(self):
        self.running = False