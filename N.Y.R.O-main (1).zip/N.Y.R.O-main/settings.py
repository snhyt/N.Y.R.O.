import os
import json
from PyQt6.QtWidgets import QDialog, QVBoxLayout, QHBoxLayout, QLabel, QLineEdit, QPushButton, QFrame
from PyQt6.QtCore import Qt, QPoint

class APIKeyDialog(QDialog):
    def __init__(self):
        super().__init__()
        
        # 1. Remove the boring OS window borders and make it float seamlessly
        self.setWindowFlags(Qt.WindowType.FramelessWindowHint | Qt.WindowType.WindowStaysOnTopHint)
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        self.resize(600, 300)

        self._old_pos = None # Used for custom window dragging

        # 2. Main Cyberpunk Wrapper Frame
        self.main_frame = QFrame(self)
        self.main_frame.setStyleSheet("""
            QFrame {
                background-color: #050000;
                border: 2px solid #ff0000;
                border-radius: 12px;
            }
        """)
        
        master_layout = QVBoxLayout(self)
        master_layout.setContentsMargins(0, 0, 0, 0)
        master_layout.addWidget(self.main_frame)

        self.layout = QVBoxLayout(self.main_frame)
        self.layout.setContentsMargins(25, 20, 25, 30)
        self.layout.setSpacing(20)

        # 3. Custom Top Bar & Close Button
        top_bar = QHBoxLayout()
        
        self.title_label = QLabel("SYSTEM OVERRIDE // AUTHORIZATION REQUIRED")
        self.title_label.setStyleSheet("""
            color: #ff0000; 
            font-family: 'Courier New', monospace; 
            font-size: 15px; 
            font-weight: bold; 
            border: none;
            letter-spacing: 1px;
        """)
        
        self.close_btn = QPushButton("✕")
        self.close_btn.setFixedSize(30, 30)
        self.close_btn.setCursor(Qt.CursorShape.PointingHandCursor)
        self.close_btn.setStyleSheet("""
            QPushButton {
                background-color: transparent;
                color: #ff0000;
                font-size: 16px;
                font-weight: bold;
                border: none;
            }
            QPushButton:hover {
                color: #ffffff;
                background-color: #ff0000;
                border-radius: 15px;
            }
        """)
        self.close_btn.clicked.connect(self.reject)
        
        top_bar.addWidget(self.title_label)
        top_bar.addStretch()
        top_bar.addWidget(self.close_btn)
        self.layout.addLayout(top_bar)

        # Decorative Separator Line
        line = QFrame()
        line.setFrameShape(QFrame.Shape.HLine)
        line.setStyleSheet("background-color: #aa0000; border: none; max-height: 1px;")
        self.layout.addWidget(line)

        # 4. Terminal Instructions
        self.sub_label = QLabel("NEURAL NET LINK OFFLINE.\nPLEASE INPUT GOOGLE AI STUDIO API KEY TO SYNCHRONIZE N.Y.R.O. CORE.")
        self.sub_label.setStyleSheet("""
            color: #ffcccc; 
            font-family: 'Courier New', monospace; 
            font-size: 12px; 
            border: none;
            line-height: 1.5;
        """)
        self.layout.addWidget(self.sub_label)

        # 5. High-Tech Input Field (Flashes Green when typing)
        self.input = QLineEdit()
        self.input.setPlaceholderText("Paste API key here...")
        # EchoMode hides the key visually like a password, but shows it briefly while typing
        self.input.setEchoMode(QLineEdit.EchoMode.PasswordEchoOnEdit)
        self.input.setStyleSheet("""
            QLineEdit {
                background-color: #0a0000;
                border: 1px solid #550000;
                border-radius: 5px;
                color: #00ff33;
                padding: 15px;
                font-size: 15px;
                font-family: 'Courier New', monospace;
                letter-spacing: 2px;
            }
            QLineEdit:focus {
                border: 1px solid #ff0000;
                background-color: #000000;
            }
        """)
        self.layout.addWidget(self.input)

        # 6. Tactical Connect Button
        self.button = QPushButton("INITIALIZE CONNECTION")
        self.button.setFixedHeight(50)
        self.button.setCursor(Qt.CursorShape.PointingHandCursor)
        self.button.setStyleSheet("""
            QPushButton {
                background-color: #330000;
                color: #ff0000;
                font-size: 15px;
                font-weight: bold;
                font-family: 'Courier New', monospace;
                letter-spacing: 3px;
                border: 1px solid #ff0000;
                border-radius: 5px;
            }
            QPushButton:hover {
                background-color: #ff0000;
                color: #ffffff;
            }
            QPushButton:pressed {
                background-color: #aa0000;
            }
        """)
        self.button.clicked.connect(self.save_key)
        self.layout.addWidget(self.button)

    # ==========================================
    # Custom Window Drag Controls
    # ==========================================
    def mousePressEvent(self, event):
        if event.button() == Qt.MouseButton.LeftButton:
            self._old_pos = event.globalPosition().toPoint()

    def mouseMoveEvent(self, event):
        if self._old_pos is not None:
            delta = event.globalPosition().toPoint() - self._old_pos
            self.move(self.pos() + delta)
            self._old_pos = event.globalPosition().toPoint()

    def mouseReleaseEvent(self, event):
        if event.button() == Qt.MouseButton.LeftButton:
            self._old_pos = None

    # ==========================================
    # Logic
    # ==========================================
    def save_key(self):
        key = self.input.text().strip()
        if not key:
            return  # Do nothing if the box is empty
            
        folder_path = "config"
        file_path = os.path.join(folder_path, "config.json")
        
        if not os.path.exists(folder_path):
            os.makedirs(folder_path)
            
        with open(file_path, "w") as f:
            json.dump({"api_key": key}, f)
            
        self.accept()