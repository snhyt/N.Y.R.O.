# setup.py
import subprocess
import sys
from pathlib import Path

BASE_DIR = Path(__file__).parent

print("Installing requirements...")
subprocess.run([sys.executable, "-m", "pip", "install", "-r", str(BASE_DIR / "requirements.txt")], check=True)
print("Installing Playwright browsers...")
subprocess.run([sys.executable, "-m", "playwright", "install"], check=True)

print("\n✅ Setup complete! Run 'python main.py' to start MARK XLVI.")