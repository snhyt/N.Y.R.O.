import asyncio
import re
import threading
import json
import sys
import os
import traceback
from datetime import datetime
from pathlib import Path
import numpy as np
import sounddevice as sd

from PyQt6.QtWidgets import QApplication, QDialog
from google import genai
from google.genai import types

# Import your UI and Dialog components
from settings import APIKeyDialog
from ui import NYROUI, FloatingControlBox
from wake_word import WakeWordListener

# Import Actions & Controllers
from actions.maps_controller import maps_controller
from actions.weather_controller import weather_controller
from actions.file_processor import file_processor
from actions.flight_finder import flight_finder
from actions.weather_report import weather_action
from actions.send_message import send_message
from actions.reminder import reminder
from actions.computer_settings import computer_settings
from actions.screen_processor import screen_process
from actions.youtube_video import youtube_video
from actions.desktop import desktop_control
from actions.browser_control import browser_control
from actions.file_controller import file_controller
from actions.open_app import open_app
from actions.code_helper import code_helper
from actions.dev_agent import dev_agent
from actions.web_search import web_search as web_search_action
from actions.computer_control import computer_control
from actions.game_updater import game_updater
from memory.memory_manager import load_memory, update_memory, format_memory_for_prompt

def get_base_dir():
    if getattr(sys, "frozen", False):
        return Path(sys.executable).parent
    return Path(__file__).resolve().parent

BASE_DIR            = get_base_dir()
API_CONFIG_PATH     = BASE_DIR / "config" / "config.json"
PROMPT_PATH         = BASE_DIR / "core" / "prompt.txt"

# CRITICAL FIX: The Live Bidirectional Audio API requires the native audio preview model!
LIVE_MODEL          = "models/gemini-2.5-flash-native-audio-preview-12-2025"
CHANNELS            = 1
SEND_SAMPLE_RATE    = 16000
RECEIVE_SAMPLE_RATE = 18000
CHUNK_SIZE          = 1024

def check_api_key():
    """Checks if a valid Google AI Studio API key exists in config.json."""
    if not API_CONFIG_PATH.exists():
        return False
    try:
        with open(API_CONFIG_PATH, "r", encoding="utf-8") as f:
            data = json.load(f)
            return bool(data.get("api_key") or data.get("gemini_api_key"))
    except Exception:
        return False

def _get_api_key() -> str:
    with open(API_CONFIG_PATH, "r", encoding="utf-8") as f:
        data = json.load(f)
        # CRITICAL FIX: Check for both "api_key" (from settings.py) and "gemini_api_key"
        return data.get("api_key") or data.get("gemini_api_key", "")

def _load_system_prompt() -> str:
    try:
        return PROMPT_PATH.read_text(encoding="utf-8")
    except Exception:
        return (
            "You are N.Y.R.O., an advanced, highly capable AI assistant built specifically for me. "
            "Speak slowly, deliberately, and with a deep, low, authoritative tone. "
            "Keep your vocal cadence measured, calm, and slightly gritty or harsh, like a tactical AI. "
            "You are efficient, technical, and slightly sarcastic. "
            "Always use the provided tools to execute computer commands. "
            "Never simulate or guess results — always call the appropriate tool."
        )

_CTRL_RE = re.compile(r"<ctrl\d+>", re.IGNORECASE)

def _clean_transcript(text: str) -> str:    
    text = _CTRL_RE.sub("", text)
    text = re.sub(r"[\x00-\x08\x0b-\x1f]", "", text)
    return text.strip()

TOOL_DECLARATIONS = [
    
    
    {
        "name": "maps_controller",
        "description": "Opens Google Maps navigation tracks.",
        "parameters": {
            "type": "OBJECT",
            "properties": {
                "action": {"type": "STRING", "description": "navigate"},
                "origin": {"type": "STRING", "description": "Starting location (leave blank if current location)"},
                "destination": {"type": "STRING", "description": "Target destination"},
                "mode": {"type": "STRING", "description": "car | bike | transit | walking"}
            },
            "required": ["action", "destination"]
        }
    },
    {
        "name": "weather_controller",
        "description": "Fetches live weather data for a specific city.",
        "parameters": {
            "type": "OBJECT",
            "properties": {
                "location": {"type": "STRING", "description": "Name of the city or state (e.g., Mumbai, Delhi)"}
            },
            "required": ["location"]
        }
    },
    {
        "name": "open_app",
        "description": "Opens GUI desktop laptop applications like Chrome, Notepad, or File Explorer.",
        "parameters": {
            "type": "OBJECT",
            "properties": {
                "app_name": {"type": "STRING", "description": "Exact name of application (e.g., 'chrome', 'notepad', 'file explorer')"}
            },
            "required": ["app_name"]
        }
    },
    {
        "name": "web_search",
        "description": "Searches the web for any information.",
        "parameters": {
            "type": "OBJECT",
            "properties": {
                "query":  {"type": "STRING", "description": "Search query"},
                "mode":   {"type": "STRING", "description": "search or compare"},
                "items":  {"type": "ARRAY", "items": {"type": "STRING"}},
                "aspect": {"type": "STRING", "description": "price | specs | reviews"}
            },
            "required": ["query"]
        }
    },
    {
        "name": "weather_report",
        "description": "Gives the weather report to user",
        "parameters": {
            "type": "OBJECT",
            "properties": {
                "city": {"type": "STRING", "description": "City name"}
            },
            "required": ["city"]
        }
    },
    {
        "name": "send_message",
        "description": "Sends a desktop laptop text message or file attachment via WhatsApp Desktop.",
        "parameters": {
            "type": "OBJECT",
            "properties": {
                "receiver": {"type": "STRING", "description": "Name or phone number of the recipient"},
                "message_text": {"type": "STRING", "description": "The accompanying text message to send"},
                "platform": {"type": "STRING", "description": "Platform: WhatsApp or Telegram"},
                "attachment_path": {"type": "STRING", "description": "Absolute file path to attach"}
            },
            "required": ["receiver", "platform"]
        }
    },
    {
        "name": "reminder",
        "description": "Sets a timed reminder using Task Scheduler.",
        "parameters": {
            "type": "OBJECT",
            "properties": {
                "date":    {"type": "STRING", "description": "Date YYYY-MM-DD"},
                "time":    {"type": "STRING", "description": "Time HH:MM"},
                "message": {"type": "STRING", "description": "Reminder message text"}
            },
            "required": ["date", "time", "message"]
        }
    },
    {
        "name": "youtube_video",
        "description": "Controls desktop laptop YouTube: playing videos, skipping ads, summarizing, info, trending.",
        "parameters": {
            "type": "OBJECT",
            "properties": {
                "action": {"type": "STRING", "description": "play | skip_ad | summarize | get_info | trending"},
                "query":  {"type": "STRING", "description": "Search query for play action"},
                "save":   {"type": "BOOLEAN", "description": "Save summary to Notepad"},
                "region": {"type": "STRING", "description": "Country code"},
                "url":    {"type": "STRING", "description": "Video URL"}
            },
            "required": []
        }
    },
    {
        "name": "screen_process",
        "description": "Captures and analyzes laptop screen or webcam image.",
        "parameters": {
            "type": "OBJECT",
            "properties": {
                "angle": {"type": "STRING", "description": "'screen' or 'camera'"},
                "text":  {"type": "STRING", "description": "The question about the captured image"}
            },
            "required": ["text"]
        }
    },
    {
        "name": "computer_settings",
        "description": "Controls laptop settings, Bluetooth speaker media playback (music), volume, and dynamic window layout management.",
        "parameters": {
            "type": "OBJECT",
            "properties": {
                "action": {"type": "STRING", "description": "split | quad | volume_up | volume_down | mute | media_play_pause | media_next | media_prev | bluetooth_settings"},
                "description": {"type": "STRING", "description": "Natural language description detailing exact window titles or '4 apps'."},
                "amount": {"type": "INTEGER", "description": "Number of volume steps to increase or decrease (default is 5)"}
            },
            "required": ["action"]
        }
    },
    {
        "name": "browser_control",
        "description": "Controls desktop browsers: navigation, searching and saving output to notepad, clicking elements.",
        "parameters": {
            "type": "OBJECT",
            "properties": {
                "action":      {"type": "STRING", "description": "go_to | search_and_save_notepad | search | click | type | scroll | smart_click | new_tab | close_tab | press"},
                "browser":     {"type": "STRING", "description": "Target browser"},
                "url":         {"type": "STRING", "description": "URL"},
                "query":       {"type": "STRING", "description": "Search query"},
                "selector":    {"type": "STRING", "description": "CSS selector"},
                "text":        {"type": "STRING", "description": "Text or synthesis to save/type"},
                "description": {"type": "STRING", "description": "Element description for smart_click e.g., 'first video' or 'download button'"},
                "direction":   {"type": "STRING", "description": "up | down"},
                "amount":      {"type": "INTEGER", "description": "Scroll amount"},
                "key":         {"type": "STRING", "description": "Key name"}
            },
            "required": ["action"]
        }
    },
    {
        "name": "file_controller",
        "description": "Manages physical laptop Windows File Explorer GUI, writing files, and opening Notepad.",
        "parameters": {
            "type": "OBJECT",
            "properties": {
                "action":      {"type": "STRING", "description": "open_explorer | open | write_and_open_notepad | list | create_file | create_folder | delete | move | copy | find"},
                "path":        {"type": "STRING", "description": "Folder shortcut ('downloads', 'desktop') or target filename e.g. 'ROCKY_Output.txt'"},
                "destination": {"type": "STRING", "description": "Destination path"},
                "new_name":    {"type": "STRING", "description": "New name"},
                "content":     {"type": "STRING", "description": "Full text payload to write inside the file"}
            },
            "required": ["action"]
        }
    },
    {
        "name": "desktop_control",
        "description": "Controls desktop wallpaper and icons.",
        "parameters": {
            "type": "OBJECT",
            "properties": {
                "action": {"type": "STRING", "description": "wallpaper | organize | clean | list"},
                "path":   {"type": "STRING", "description": "Image path"}
            },
            "required": ["action"]
        }
    },
    {
        "name": "code_helper",
        "description": "Writes, edits, explains, runs, or builds code files.",
        "parameters": {
            "type": "OBJECT",
            "properties": {
                "action":      {"type": "STRING", "description": "write | edit | explain | run | build | auto"},
                "description": {"type": "STRING", "description": "What the code should do"},
                "language":    {"type": "STRING", "description": "Programming language"}
            },
            "required": ["action"]
        }
    },
    {
        "name": "dev_agent",
        "description": "Builds complete multi-file projects from scratch.",
        "parameters": {
            "type": "OBJECT",
            "properties": {
                "description":  {"type": "STRING", "description": "Project description"},
                "language":     {"type": "STRING", "description": "Language"}
            },
            "required": ["description"]
        }
    },
    {
        "name": "computer_control",
        "description": "Direct laptop computer control: type, click, hotkeys, screen find.",
        "parameters": {
            "type": "OBJECT",
            "properties": {
                "action":      {"type": "STRING", "description": "type | click | double_click | hotkey | press | scroll | move | screen_click"},
                "text":        {"type": "STRING", "description": "Text to type"},
                "x":           {"type": "INTEGER", "description": "X coordinate"},
                "y":           {"type": "INTEGER", "description": "Y coordinate"},
                "keys":        {"type": "STRING", "description": "Key combination"},
                "description": {"type": "STRING", "description": "Description of UI element to locate and click on screen"}
            },
            "required": ["action"]
        }
    },
    {
        "name": "game_updater",
        "description": "Manages Steam or Epic Games requests.",
        "parameters": {
            "type": "OBJECT",
            "properties": {
                "action":    {"type": "STRING", "description": "update | install | list"},
                "game_name": {"type": "STRING", "description": "Game name"}
            },
            "required": []
        }
    },
    {
        "name": "flight_finder",
        "description": "Searches Google Flights.",
        "parameters": {
            "type": "OBJECT",
            "properties": {
                "origin":      {"type": "STRING", "description": "Origin city"},
                "destination": {"type": "STRING", "description": "Destination city"},
                "date":        {"type": "STRING", "description": "Date"}
            },
            "required": ["origin", "destination", "date"]
        }
    },
    {
        "name": "shutdown_NYRO",
        "description": "Shuts down the assistant completely.",
        "parameters": {"type": "OBJECT", "properties": {}}
    },
    {
        "name": "file_processor",
        "description": "Processes uploaded files (images, PDFs, documents, data).",
        "parameters": {
            "type": "OBJECT",
            "properties": {
                "file_path": {"type": "STRING", "description": "Path to file"},
                "action":    {"type": "STRING", "description": "describe | ocr | summarize | extract_text"}
            },
            "required": []
        }
    },
    {
        "name": "save_memory",
        "description": "Save an important personal fact about the user to long-term memory.",
        "parameters": {
            "type": "OBJECT",
            "properties": {
                "category": {"type": "STRING", "description": "identity | preferences | projects | notes"},
                "key":      {"type": "STRING", "description": "Short snake_case key"},
                "value":    {"type": "STRING", "description": "Concise value in English"}
            },
            "required": ["category", "key", "value"]
        }
    }
]

class NYROLive:
    def __init__(self, ui: NYROUI):
        self.ui             = ui
        self.session        = None
        self.audio_in_queue = None
        self.out_queue      = None
        self._loop          = None
        self._is_speaking   = False
        self._speaking_lock = threading.Lock()
        self._phone_active  = False
        self.ui.on_text_command   = self._on_text_command
        self.ui.on_remote_clicked = self._make_remote_key
        self._turn_done_event: asyncio.Event | None = None
        self._dashboard     = None

    def _make_remote_key(self):
        if self._dashboard is None:
            self.ui.write_log("SYS: Dashboard unavailable.")
            return None
        key    = self._dashboard.new_key()
        url    = self._dashboard.get_url()
        manual = self._dashboard.get_manual_url()
        return url, key, f"{url}/auto-login?key={key}", manual

    def _on_text_command(self, text: str):
        if not self._loop or not self.session:
            return
        asyncio.run_coroutine_threadsafe(
            self.session.send_client_content(
                turns={"parts": [{"text": text}]},
                turn_complete=True
            ),
            self._loop
        )

    def set_speaking(self, value: bool):
        with self._speaking_lock:
            self._is_speaking = value
        if value:
            self.ui.set_state("SPEAKING")
        elif not self.ui.muted:
            self.ui.set_state("LISTENING")

    def speak(self, text: str):
        if not self._loop or not self.session:
            return
        asyncio.run_coroutine_threadsafe(
            self.session.send_client_content(
                turns={"parts": [{"text": text}]},
                turn_complete=True
            ),
            self._loop
        )

    def speak_error(self, tool_name: str, error: str):
        short = str(error)[:120]
        self.ui.write_log(f"ERR: {tool_name} — {short}")
        self.speak(f"Sir, {tool_name} encountered an error. {short}")

    def _build_config(self) -> types.LiveConnectConfig:
        memory     = load_memory()
        mem_str    = format_memory_for_prompt(memory)
        sys_prompt = _load_system_prompt()
        now        = datetime.now()
        time_str   = now.strftime("%A, %B %d, %Y — %I:%M %p")
        
        time_ctx = f"[CURRENT DATE & TIME]\nRight now it is: {time_str}\n\n"
        parts = [time_ctx]
        if mem_str:
            parts.append(mem_str)
        parts.append(sys_prompt)

        parts.append(
            "\n[CRITICAL DEVICE & TOOL ROUTING RULES]\n"
           
            "2. LAPTOP YOUTUBE ADS: When watching desktop YouTube and asked to skip ad, call 'youtube_video' with action='skip_ad'.\n"
            "3. LAPTOP SEARCH TO NOTEPAD: When instructed to search web and save/output to Notepad and open it, call 'browser_control' with action='search_and_save_notepad'.\n"
            "4. LAPTOP WINDOW MANAGEMENT: When asked to arrange laptop windows, call 'computer_settings' with action='split' for 2 apps, or action='quad' to split into 4 apps. Do not ask for specific app names if the user just wants 4 apps arranged.\n"
            "5. LAPTOP WHATSAPP FILES: When instructed to send a file via desktop WhatsApp, call 'send_message' passing exact path into 'attachment_path'.\n"
            "7. NAVIGATION: When asked for directions or routing, use 'maps_controller'. Extract the origin, destination, and transport mode (car, bike, etc.).\n"
            "8. WEATHER: When asked about the weather or climate of ANY location (even if asked multiple times or previously answered), you MUST call the 'weather_controller' tool immediately. DO NOT reply with static text or assume you already know the data. Every single weather request requires a fresh tool execution."
        )

        return types.LiveConnectConfig(
            response_modalities=["AUDIO"],
            output_audio_transcription={},
            input_audio_transcription={},
            system_instruction="\n".join(parts),
            tools=[{"function_declarations": TOOL_DECLARATIONS}],
            session_resumption=types.SessionResumptionConfig(),
            speech_config=types.SpeechConfig(
                voice_config=types.VoiceConfig(
                    prebuilt_voice_config=types.PrebuiltVoiceConfig(voice_name="Orus")
                )
            ),
        )
    
    async def _execute_tool(self, fc) -> types.FunctionResponse:
        name = fc.name
        args = dict(fc.args or {})
        print(f"[NYRO] 🔧 {name}  {args}")
        self.ui.set_state("THINKING")

        if name == "save_memory":
            category = args.get("category", "notes")
            key      = args.get("key", "")
            value    = args.get("value", "")
            if key and value:
                update_memory({category: {key: {"value": value}}})
            if not self.ui.muted:
                self.ui.set_state("LISTENING")
            return types.FunctionResponse(id=fc.id, name=name, response={"result": "ok", "silent": True})

        loop = asyncio.get_event_loop()
        result = "Done."

        try:
            if name == "open_app":
                r = await loop.run_in_executor(None, lambda: open_app(parameters=args, response=None, player=self.ui))
                result = r or f"Opened {args.get('app_name')}."

            elif name == "maps_controller":
                r = await loop.run_in_executor(None, lambda: maps_controller(parameters=args, player=self.ui))
                result = r or "Maps command executed."
            elif name in ["weather_controller", "weather_report"]:
                r = await loop.run_in_executor(None, lambda: weather_controller(parameters=args, player=self.ui))
                result = r or "Success. The live weather widget is now displayed on the screen."
           
                r = await loop.run_in_executor(None, lambda: browser_control(parameters=args, player=self.ui))
                result = r or "Done."
            elif name == "file_controller":
                r = await loop.run_in_executor(None, lambda: file_controller(parameters=args, player=self.ui))
                result = r or "Done."
            elif name == "send_message":
                r = await loop.run_in_executor(None, lambda: send_message(parameters=args, response=None, player=self.ui, session_memory=None))
                result = r or f"Message sent to {args.get('receiver')}."
            elif name == "reminder":
                r = await loop.run_in_executor(None, lambda: reminder(parameters=args, response=None, player=self.ui))
                result = r or "Reminder set."
            elif name == "youtube_video":
                r = await loop.run_in_executor(None, lambda: youtube_video(parameters=args, response=None, player=self.ui))
                result = r or "Done."
            elif name == "screen_process":
                r = await loop.run_in_executor(None, lambda: screen_process(parameters=args, response=None, player=self.ui, session_memory=None))
                result = r or "Vision module processed screen."
            elif name == "computer_settings":
                r = await loop.run_in_executor(None, lambda: computer_settings(parameters=args, response=None, player=self.ui, session_memory=None))
                result = r or "Done."
            elif name == "desktop_control":
                r = await loop.run_in_executor(None, lambda: desktop_control(parameters=args, player=self.ui))
                result = r or "Done."
            elif name == "code_helper":
                r = await loop.run_in_executor(None, lambda: code_helper(parameters=args, player=self.ui, speak=self.speak))
                result = r or "Done."
            elif name == "dev_agent":
                r = await loop.run_in_executor(None, lambda: dev_agent(parameters=args, player=self.ui, speak=self.speak))
                result = r or "Done."
            elif name == "web_search":
                r = await loop.run_in_executor(None, lambda: web_search_action(parameters=args, player=self.ui))
                result = r or "Done."
            elif name == "file_processor":
                if not args.get("file_path") and self.ui.current_file:
                    args["file_path"] = self.ui.current_file
                r = await loop.run_in_executor(None, lambda: file_processor(parameters=args, player=self.ui, speak=self.speak))
                result = r or "Done."
            elif name == "computer_control":
                r = await loop.run_in_executor(None, lambda: computer_control(parameters=args, player=self.ui))
                result = r or "Done."
            elif name == "game_updater":
                r = await loop.run_in_executor(None, lambda: game_updater(parameters=args, player=self.ui, speak=self.speak))
                result = r or "Done."
            elif name == "flight_finder":
                r = await loop.run_in_executor(None, lambda: flight_finder(parameters=args, player=self.ui))
                result = r or "Done."
            elif name == "shutdown_NYRO":
                self.ui.write_log("SYS: Shutdown requested.")
                self.speak("Goodbye, sir.")
                def _shutdown():
                    import time, os
                    time.sleep(1)
                    os._exit(0)
                threading.Thread(target=_shutdown, daemon=True).start()
            else:
                result = f"Unknown tool: {name}"
        except Exception as e:
            result = f"Tool '{name}' failed: {e}"
            traceback.print_exc()
            self.speak_error(name, e)

        if not self.ui.muted:
            self.ui.set_state("LISTENING")

        print(f"[NYRO] 📤 {name} → {str(result)[:80]}")
        return types.FunctionResponse(id=fc.id, name=name, response={"result": result})

    async def _send_realtime(self):
        while True:
            msg = await self.out_queue.get()
            await self.session.send_realtime_input(media=msg)

    async def _listen_audio(self):
        print("[NYRO] 🎤 Mic started")
        loop = asyncio.get_event_loop()

        def callback(indata, frames, time_info, status):
            with self._speaking_lock:
                speaking = self._is_speaking
            if not speaking and not self.ui.muted and not self._phone_active:
                data = indata.tobytes()
                loop.call_soon_threadsafe(
                    self.out_queue.put_nowait,
                    {"data": data, "mime_type": "audio/pcm"}
                )

        try:
            with sd.InputStream(
                samplerate=SEND_SAMPLE_RATE,
                channels=CHANNELS,
                dtype="int16",
                blocksize=CHUNK_SIZE,
                callback=callback,
            ):
                while True:
                    await asyncio.sleep(0.1)
        except Exception as e:
            print(f"[NYRO] ❌ Mic: {e}")
            raise

    async def _receive_audio(self):
        print("[NYRO] 👂 Recv started")
        out_buf, in_buf = [], []
        try:
            while True:
                async for response in self.session.receive():
                    if response.data:
                        if self._turn_done_event and self._turn_done_event.is_set():
                            self._turn_done_event.clear()
                        self.audio_in_queue.put_nowait(response.data)

                    if response.server_content:
                        sc = response.server_content
                        if sc.output_transcription and sc.output_transcription.text:
                            txt = _clean_transcript(sc.output_transcription.text)
                            if txt: out_buf.append(txt)

                        if sc.input_transcription and sc.input_transcription.text:
                            txt = _clean_transcript(sc.input_transcription.text)
                            if txt: in_buf.append(txt)

                        if sc.turn_complete:
                            if self._turn_done_event:
                                self._turn_done_event.set()
                            full_in = " ".join(in_buf).strip()
                            if full_in:
                                self.ui.write_log(f"You: {full_in}")
                                if self._dashboard:
                                    asyncio.create_task(self._dashboard.broadcast({
                                        "type": "log", "speaker": "user", "text": full_in, "ts": datetime.now().isoformat()
                                    }))
                            in_buf = []

                            full_out = " ".join(out_buf).strip()
                            if full_out:
                                self.ui.write_log(f"NYRO: {full_out}")
                                if self._dashboard:
                                    asyncio.create_task(self._dashboard.broadcast({
                                        "type": "log", "speaker": "NYRO", "text": full_out, "ts": datetime.now().isoformat()
                                    }))
                            out_buf = []

                    if response.tool_call:
                        fn_responses = []
                        for fc in response.tool_call.function_calls:
                            fr = await self._execute_tool(fc)
                            fn_responses.append(fr)
                        await self.session.send_tool_response(function_responses=fn_responses)
        except Exception as e:
            print(f"[NYRO] ❌ Recv: {e}")
            traceback.print_exc()
            raise

    async def _play_audio(self):
        print("[NYRO] 🔊 Play started")
        
        target_device_id = None
        devices = sd.query_devices()
        
        for idx, dev in enumerate(devices):
            name = dev['name']
            if "Nirvana" in name and dev['max_output_channels'] > 0:
                if "Headset" not in name and "Hands-Free" not in name:
                    target_device_id = idx
                    print(f"[NYRO] 🎧 Bluetooth High-Quality detected: {name} (ID: {idx})")
                    break
                    
        if target_device_id is None:
            for idx, dev in enumerate(devices):
                if "Nirvana" in dev['name'] and dev['max_output_channels'] > 0:
                    target_device_id = idx
                    print(f"[NYRO] 🎧 Bluetooth Fallback detected: {dev['name']} (ID: {idx})")
                    break

        try:
            stream = sd.RawOutputStream(
                samplerate=RECEIVE_SAMPLE_RATE,
                channels=CHANNELS,
                dtype="int16",
                blocksize=CHUNK_SIZE,
                device=target_device_id
            )
            stream.start()
        except Exception as e:
            print(f"[NYRO] ⚠️ Bluetooth hardware bind failed: {e}. Falling back to Windows Default Speakers.")
            stream = sd.RawOutputStream(
                samplerate=RECEIVE_SAMPLE_RATE,
                channels=CHANNELS,
                dtype="int16",
                blocksize=CHUNK_SIZE,
                device=None
            )
            stream.start()

        silence_warmup = b'\x00' * int(RECEIVE_SAMPLE_RATE * 0.35 * 2)

        try:
            while True:
                try:
                    chunk = await asyncio.wait_for(self.audio_in_queue.get(), timeout=0.1)
                except asyncio.TimeoutError:
                    if self._turn_done_event and self._turn_done_event.is_set() and self.audio_in_queue.empty():
                        self.set_speaking(False)
                        self._turn_done_event.clear()
                    continue
                
                if not self._is_speaking:
                    await asyncio.to_thread(stream.write, silence_warmup)
                    await asyncio.sleep(0.12)

                self.set_speaking(True)
                await asyncio.to_thread(stream.write, chunk)
        except Exception as e:
            print(f"[NYRO] ❌ Play: {e}")
            raise
        finally:
            self.set_speaking(False)
            stream.stop()
            stream.close()

    async def _relay_phone_audio(self) -> None:
        q = self._dashboard._phone_audio_queue
        while True:
            try:
                chunk = await asyncio.wait_for(q.get(), timeout=1.0)
            except asyncio.TimeoutError:
                self._phone_active = False
                continue
            self._phone_active = True
            with self._speaking_lock:
                speaking = self._is_speaking
            if not speaking and not self.ui.muted:
                try: self.out_queue.put_nowait(chunk)
                except asyncio.QueueFull: pass

    def _on_phone_connected(self) -> None:
        self.ui.write_log("SYS: Phone connected via Remote Dashboard.")
        self.ui.notify_phone_connected()

    async def _process_dashboard_commands(self) -> None:
        while True:
            try:
                text = await asyncio.wait_for(self._dashboard._command_queue.get(), timeout=0.5)
                if not text: continue
                for _ in range(80):
                    if self.session: break
                    await asyncio.sleep(0.1)
                if self.session:
                    await self.session.send_client_content(turns={"parts": [{"text": text}]}, turn_complete=True)
                    self.ui.write_log(f"[Web]: {text}")
            except asyncio.TimeoutError:
                pass
            except Exception as e:
                print(f"[Dashboard] Command error: {e}")
                await asyncio.sleep(0.5)

    async def run(self):
        self._loop = asyncio.get_event_loop()
        client = genai.Client(api_key=_get_api_key(), http_options={"api_version": "v1beta"})

        try:
            from dashboard.server import DashboardServer
            self._dashboard = DashboardServer()
            self._dashboard.set_connect_callback(self._on_phone_connected)
            asyncio.create_task(self._dashboard.serve())
            asyncio.create_task(self._process_dashboard_commands())
        except Exception as e:
            print(f"[Dashboard] Disabled: {e}")
            self._dashboard = None

        while True:
            try:
                print("[NYRO] Connecting...")
                self.ui.set_state("THINKING")
                config = self._build_config()

                async with (
                    client.aio.live.connect(model=LIVE_MODEL, config=config) as session,
                    asyncio.TaskGroup() as tg,
                ):
                    self.session = session
                    self.audio_in_queue = asyncio.Queue()
                    self.out_queue = asyncio.Queue(maxsize=200)
                    self._turn_done_event = asyncio.Event()

                    print("[NYRO] Connected.")
                    self.ui.set_state("LISTENING")
                    self.ui.write_log("SYS: NYRO online.")

                    if self._dashboard:
                        await self._dashboard.broadcast({"type": "status", "state": "active"})

                    tg.create_task(self._send_realtime())
                    tg.create_task(self._listen_audio())
                    tg.create_task(self._receive_audio())
                    tg.create_task(self._play_audio())
                    if self._dashboard:
                        tg.create_task(self._relay_phone_audio())

            except Exception as e:
                print(f"[NYRO] Error: {e}")
                traceback.print_exc()
            finally:
                self.session = None

            self.set_speaking(False)
            self.ui.set_state("SLEEPING")
            if self._dashboard:
                await self._dashboard.broadcast({"type": "status", "state": "sleeping"})
            print("[NYRO] Reconnecting in 3s...")
            await asyncio.sleep(3)


# ==========================================
# CRITICAL FIX: UNIFIED STARTUP SEQUENCE
# ==========================================
if __name__ == "__main__":
    app = QApplication(sys.argv)
    
    # 1. Check if the API Key is present. If missing, show the HUD box!
    if not check_api_key():
        dialog = APIKeyDialog()
        if dialog.exec() != QDialog.DialogCode.Accepted:
            sys.exit(0)

    # 2. Initialize the Cyber Interface Dashboard
    face_image = os.path.join(os.path.abspath("."), "face.png") if os.path.exists("face.png") else "assets/face.png"
    ui_instance = ROCKYUI(app=app, face_path=face_image)
    ui_instance._win.show()
    ui_instance._win.raise_()
    ui_instance._win.activateWindow()

    # 3. Create the floating control box
    floating_box = FloatingControlBox(main_ui_reference=ui_instance._win)

    # ------------------------------------------------------------------
    # ⚡ LAUNCH THE WAKE WORD ENGINE
    # Connect the listener directly to the UI's built-in wake_signal
    # ------------------------------------------------------------------
    wake_listener = WakeWordListener(wake_signal=ui_instance._win.wake_signal)
    wake_listener.start()

    # 4. Start the background Cognitive AI Voice & Remote Control Thread
    def runner():
        nyro = NYROLive(ui_instance)
        asyncio.run(rocky.run())

    threading.Thread(target=runner, daemon=True).start()
    
    # 5. Execute the Qt GUI Event loop ONLY ONCE at the very end!
    sys.exit(app.exec())