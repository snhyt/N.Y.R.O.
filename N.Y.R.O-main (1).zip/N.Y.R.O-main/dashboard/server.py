# dashboard/server.py
import asyncio
import secrets
import socket
import uvicorn
from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.responses import HTMLResponse

app = FastAPI(title="N.Y.R.O Remote Core")

class DashboardServer:
    def __init__(self, host: str = "0.0.0.0", port: int = 8000):
        self.host = host
        self.port = port
        self.current_key = self._generate_secure_key()
        self._phone_audio_queue = asyncio.Queue()
        self._command_queue = asyncio.Queue()
        self.connected_sockets: list[WebSocket] = []
        self.on_connect_callback = None

    def _generate_secure_key(self) -> str:
        # Generates a clean 6-digit access pin for phone validation
        return "".join(secrets.choice("0123456789") for _ in range(6))

    def new_key(self) -> str:
        self.current_key = self._generate_secure_key()
        return self.current_key

    def get_local_ip(self) -> str:
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.connect(("8.8.8.8", 80))
            ip = s.getsockname()[0]
            s.close()
            return ip
        except Exception:
            return "127.0.0.1"

    def get_url(self) -> str:
        return f"http://{self.get_local_ip()}:{self.port}"

    def get_manual_url(self) -> str:
        return f"{self.get_local_ip()}:{self.port}"

    def set_connect_callback(self, callback) -> None:
        self.on_connect_callback = callback

    async def broadcast(self, message: dict) -> None:
        # Relays telemetry out to all connected interface layers
        for ws in list(self.connected_sockets):
            try:
                await ws.send_json(message)
            except Exception:
                self.connected_sockets.remove(ws)

    async def serve(self) -> None:
        # Attaches instance reference directly onto FastAPI global state for routing access
        app.state.server_ref = self
        config = uvicorn.Config(app, host=self.host, port=self.port, log_level="warning")
        server = uvicorn.Server(config)
        await server.serve()

# ── FastAPI Routes & Web Interface Layout ──────────────────────────────────────────

@app.get("/", response_class=HTMLResponse)
async def get_dashboard_ui():
    # Serves a futuristic, mobile-optimized control room layout directly to your smartphone browser
    return """
    <!DOCTYPE html>
    <html>
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>N.Y.R.O. Dashboard</title>
        <style>
            body { background: #00060a; color: #8ffcff; font-family: 'Courier New', monospace; padding: 20px; text-align: center; }
            h2 { color: #ff1e27; border-bottom: 1px solid #330000; padding-bottom: 10px; }
            .btn { background: #011520; border: 1px solid #ff1e27; color: #ffcccc; padding: 15px 30px; font-size: 16px; font-weight: bold; border-radius: 5px; cursor: pointer; margin: 20px 0; width: 100%; max-width: 300px; }
            .btn:active { background: #330000; color: #ff1e27; border-color: #ff1e27; }
            #status { font-size: 14px; color: #cc0000; margin-top: 10px; }
            .log-box { background: #0a0000; border: 1px solid #330000; height: 150px; overflow-y: auto; text-align: left; padding: 10px; font-size: 12px; margin-top: 20px; border-radius: 4px; color: #ffcccc; }
            
            /* Chat Interface Styling */
            #chat-container { margin: 10px auto; width: 100%; max-width: 300px; display: flex; gap: 8px; }
            #command-input { flex-grow: 1; padding: 12px; border-radius: 5px; border: 1px solid #ff1e27; background-color: #0a0000; color: #ffcccc; font-family: 'Courier New', monospace; outline: none; }
            #command-input:focus { box-shadow: 0 0 5px #ff1e27; }
            #send-btn { padding: 12px 18px; background-color: #ff1e27; color: white; border: none; border-radius: 5px; font-weight: bold; cursor: pointer; font-family: inherit; }
            #send-btn:active { background-color: #aa0000; }
        </style>
    </head>
    <body>
        <h2>◈ N.Y.R.O. REMOTE LINK</h2>
        <input type="password" id="pin" placeholder="ENTER ACCESS PIN" style="background:#0a0000; border:1px solid #330000; color:#ffcccc; padding:10px; text-align:center; font-size:16px; border-radius:4px; outline: none;"><br>
        <button class="btn" id="connectBtn" onclick="initiateLink()">ESTABLISH CONNECTION</button>
        
        <div id="controlPanel" style="display:none;">
            <!-- Hold to Speak Button -->
            <button class="btn" style="border-color:#ff1e27; color:#ff1e27;" onmousedown="startMic()" onmouseup="stopMic()" ontouchstart="startMic()" ontouchend="stopMic()">🎙️ HOLD TO SPEAK</button>
            
            <!-- NEW: Mobile Text Chat Interface -->
            <div id="chat-container">
                <input type="text" id="command-input" placeholder="Type a command...">
                <button id="send-btn" onclick="sendTextCommand()">SEND</button>
            </div>
            
            <div class="log-box" id="terminalLogs">Awaiting system broadcast...</div>
        </div>
        <div id="status">Status: Disconnected</div>

        <script>
            let ws;
            function initiateLink() {
                let pin = document.getElementById('pin').value;
                let protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
                ws = new WebSocket(protocol + "//" + window.location.host + "/ws/link?key=" + pin);
                
                ws.onopen = () => {
                    document.getElementById('pin').style.display = 'none';
                    document.getElementById('connectBtn').style.display = 'none';
                    document.getElementById('controlPanel').style.display = 'block';
                    document.getElementById('status').innerText = "Status: Connected to Core";
                };
                ws.onmessage = (e) => {
                    let msg = JSON.parse(e.data);
                    if(msg.type === "log") {
                        let box = document.getElementById('terminalLogs');
                        box.innerHTML += `<br>[${msg.speaker.toUpperCase()}]: ${msg.text}`;
                        box.scrollTop = box.scrollHeight;
                    }
                };
                ws.onclose = () => { document.getElementById('status').innerText = "Status: Disconnected"; };
            }
            
            function startMic() { if(ws) ws.send(JSON.stringify({type: "action", action: "mic_wake"})); }
            function stopMic() { if(ws) ws.send(JSON.stringify({type: "action", action: "mic_sleep"})); }
            
            // NEW: Send Text Command Function
            function sendTextCommand() {
                const inputField = document.getElementById('command-input');
                const text = inputField.value.trim();
                
                if (text !== "" && ws && ws.readyState === WebSocket.OPEN) {
                    ws.send(JSON.stringify({
                        type: "command",
                        text: text
                    }));
                    
                    inputField.value = "";
                    
                    const btn = document.getElementById('send-btn');
                    btn.innerText = "✓";
                    btn.style.backgroundColor = "#00ff33";
                    setTimeout(() => {
                        btn.innerText = "SEND";
                        btn.style.backgroundColor = "#ff1e27";
                    }, 1000);
                }
            }

            // Listen for Enter key press on mobile keyboard
            document.getElementById('command-input').addEventListener('keypress', function (e) {
                if (e.key === 'Enter') {
                    sendTextCommand();
                }
            });
        </script>
    </body>
    </html>
    """

@app.get("/auto-login")
async def auto_login(key: str):
    # This route allows quick camera pairing when you scan the QR overlay generated by the UI window
    return HTMLResponse(content=f"""
        <html><script>
            window.onload = function() {{
                localStorage.setItem('jarvis_pin', '{key}');
                window.location.href = '/';
            }}
        </script></html>
    """)

@app.websocket("/ws/link")
async def websocket_endpoint(websocket: WebSocket, key: str):
    server: DashboardServer = websocket.app.state.server_ref
    if key != server.current_key:
        await websocket.close(code=4003)
        return

    await websocket.accept()
    server.connected_sockets.append(websocket)
    if server.on_connect_callback:
        server.on_connect_callback()

    try:
        while True:
            # Handles incoming action variables from connected devices
            data = await websocket.receive_json()
            
            # Action Route (Voice commands from phone)
            if data.get("type") == "action":
                if data.get("action") == "mic_wake":
                    await server._command_queue.put("Wake up, NYRO.")
                elif data.get("action") == "mic_sleep":
                    pass
            
            # NEW: Command Route (Text commands from phone)
            elif data.get("type") == "command":
                text_payload = data.get("text", "").strip()
                if text_payload:
                    await server._command_queue.put(text_payload)
                    
    except WebSocketDisconnect:
        server.connected_sockets.remove(websocket)