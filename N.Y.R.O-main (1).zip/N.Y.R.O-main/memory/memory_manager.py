# memory/memory_manager.py
import json
from pathlib import Path

MEMORY_FILE = Path(__file__).resolve().parent / "long_term.json"

def load_memory() -> dict:
    if not MEMORY_FILE.exists():
        return {}
    try:
        return json.loads(MEMORY_FILE.read_text(encoding="utf-8"))
    except Exception:
        return {}

def update_memory(new_data: dict):
    memory = load_memory()
    for cat, keys in new_data.items():
        if cat not in memory:
            memory[cat] = {}
        for k, v in keys.items():
            memory[cat][k] = v
    MEMORY_FILE.write_text(json.dumps(memory, indent=4), encoding="utf-8")

def format_memory_for_prompt(memory: dict) -> str:
    if not memory:
        return ""
    lines = ["[PERSISTENT MEMORY MODULE]"]
    for cat, data in memory.items():
        lines.append(f" Category: {cat}")
        for k, v in data.items():
            lines.append(f"  - {k}: {v.get('value', '')}")
    return "\n".join(lines) + "\n"